# Continuidade — Gravity macOS

1. Leia este arquivo, `docs/ESTADO.md` e `git status --short --branch`.
2. Consulte `docs/ARQUITETURA.md` e abra somente os módulos ligados à tarefa.
3. Antes de editar, confira alterações locais e preserve trabalho existente.
4. Ao terminar, atualize `docs/ESTADO.md` somente se o estado do produto mudou. Registre decisões duradouras em `docs/ARQUITETURA.md`; evite diários, transcrições e cópias de contexto.

## Regras

- Este repositório contém exclusivamente macOS. Mac e Windows têm repositórios separados.
- Histórico, índice, credenciais, builds e arquivos temporários não pertencem ao Git.
- Não leia `arquivo-local` nem históricos de usuários para retomar contexto; consulte-os apenas para recuperação solicitada.
- Preserve a identidade do anel prismático e do Liquid Glass, contraste e acessibilidade.
- Use os comandos do README. Ao mover arquivos, ajuste build, testes e CI juntos.
- Não prometa memória permanente: mantenha os documentos curtos e atuais para permitir retomada por qualquer agente.
- Para instalação, primeiro uso, Antigravity CLI ou login Google, siga a skill `gravity-first-run` em `.agents/skills/gravity-first-run/SKILL.md` e use `docs/PRIMEIRO-USO.md` como fonte única dos passos e links.
