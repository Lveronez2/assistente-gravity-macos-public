#!/bin/zsh
set -euo pipefail
trap 'echo "Não foi possível concluir. Leia a mensagem acima."; read -r "?Pressione Enter para fechar."' ZERR
cd "${0:A:h}"
[[ "$(uname -m)" == arm64 ]] || { echo 'Este pacote requer um Mac Apple Silicon.'; exit 1; }
major="$(sw_vers -productVersion | cut -d. -f1)"
(( major >= 26 )) || { echo 'Este pacote requer macOS 26 ou mais recente.'; exit 1; }
if pgrep -x AssistenteGravity >/dev/null; then
 echo 'Feche o Assistente Gravity antes de instalar e execute este arquivo novamente.'
 read -r '?Pressione Enter para fechar.'
 exit 1
fi
sourceApp="$PWD/Assistente Gravity.app"
codesign --verify --deep --strict "$sourceApp"
root="${GRAVITY_HOME:-$HOME/Documents/Assistente Gravity}"
mkdir -p "$root/aplicativo" "$root/dados/macos" "$root/dados/backups" "$HOME/Applications"
target="$root/aplicativo/Assistente Gravity.app"
stamp="$(date +%Y%m%d-%H%M%S)"
if [[ -e "$target" ]]; then
 mv "$target" "$root/dados/backups/instalacao-$stamp"
fi
ditto "$sourceApp" "$target"
link="$HOME/Applications/Assistente Gravity.app"
if [[ -L "$link" ]]; then
 unlink "$link"
elif [[ -e "$link" && "$link" != "$target" ]]; then
 mv "$link" "$root/dados/backups/aplicativo-anterior-$stamp"
fi
ln -s "$target" "$link"
# Caminhos pertencem a cada computador. A configuração inicial será feita no app.
for key in GravityLocal GravityWork GravityServer GravityCLI; do
 defaults delete com.gravity.assistente "$key" >/dev/null 2>&1 || true
done
defaults write com.gravity.assistente GravityHistory -string "$root/dados/macos/conversations.json"
defaults write com.gravity.assistente GravitySetupComplete -bool false
open "$target"
echo "Instalado em: $target"
echo 'Escolha sua pasta de busca e conecte sua conta no próprio aplicativo.'
read -r '?Pressione Enter para fechar.'
