#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
output="${1:?Informe um diretório novo para o pacote}"
mkdir -p "$output"
output="$(cd "$output" && pwd)"
./build.sh "$output/app" release
version=$(/usr/libexec/PlistBuddy -c 'Print :CFBundleShortVersionString' Resources/Info.plist)
package="$output/Assistente-Gravity-$version-macOS"
mkdir "$package"
mv "$output/app/Assistente Gravity.app" "$package/"
rmdir "$output/app"
cp scripts/Instalar.command "$package/"
cp docs/OUTRO-MAC.md "$package/LEIA-ME.md"
xattr -cr "$package"
codesign --verify --deep --strict "$package/Assistente Gravity.app"
ditto -c -k --sequesterRsrc --keepParent "$package" "$output/Assistente-Gravity-$version-macOS.zip"
(cd "$output" && shasum -a 256 "Assistente-Gravity-$version-macOS.zip" > SHA256SUMS.txt)
echo "$output/Assistente-Gravity-$version-macOS.zip"
