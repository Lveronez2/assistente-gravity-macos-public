import Foundation
import os

enum SmartFinderEngine {
    // A network filesystem may take much longer than local storage to enumerate.
    // Keep only one recursive scan active so timed-out searches cannot pile up.
    private static let serverScanGate = DispatchSemaphore(value: 1)
    private static let localScanGate = DispatchSemaphore(value: 1)
    private static let indexSetupQueue = DispatchQueue(label: "gravity.search-index.setup", qos: .utility)
    private static let maxScopes = 24
    private static let maxScannedEntries = 12_000
    private static let maxRetainedCandidates = 10
    private static let ignoredDirectories: Set<String> = ["library", "applications", "node_modules", ".git", ".svn", ".next", "deriveddata", "build", "dist", "cache", "caches", "auto-save", "salvamento automatico"]

    /// Search-root checks and index snapshot loading can touch a large local or
    /// mounted volume, so UI actions schedule setup away from the main thread.
    static func scheduleIndexing() {
        indexSetupQueue.async { startIndexing() }
    }

    static func startIndexing() {
        let roots = GravityPaths.searchRoots()
        SearchIndexStore.shared.retainEntries(for: Set(roots.map { $0.standardizedFileURL.path }))
        let needed = SearchIndexStore.shared.rootsNeedingRefresh(roots)
        guard !needed.isEmpty else { return }
        Task.detached(priority: .utility) {
            for root in needed where SearchIndexStore.shared.begin(root) {
                let signpostID = OSSignpostID(log: SearchSignposts.log)
                os_signpost(.begin, log: SearchSignposts.log, name: "IndexRoot", signpostID: signpostID)
                defer { os_signpost(.end, log: SearchSignposts.log, name: "IndexRoot", signpostID: signpostID) }

                let capacity = SearchIndexStore.shared.capacity(replacing: root)
                guard capacity > 0 else { SearchIndexStore.shared.fail(root); break }
                var indexed: [SearchIndexEntry] = []
                guard let enumerator = FileManager.default.enumerator(
                    at: root,
                    includingPropertiesForKeys: [.isDirectoryKey, .isSymbolicLinkKey, .contentModificationDateKey],
                    options: [.skipsHiddenFiles, .skipsPackageDescendants]
                ) else {
                    SearchIndexStore.shared.fail(root)
                    continue
                }
                while let url = enumerator.nextObject() as? URL, indexed.count < capacity {
                    while SearchIndexStore.shared.shouldPauseIndexing() { try? await Task.sleep(for: .milliseconds(50)) }
                    guard let values = try? url.resourceValues(forKeys: [.isDirectoryKey, .isSymbolicLinkKey, .contentModificationDateKey]), values.isSymbolicLink != true else { continue }
                    let isDirectory = values.isDirectory == true
                    let normalizedPath = normalize(url.path)
                    let normalizedName = normalize(url.deletingPathExtension().lastPathComponent)
                    if isDirectory {
                        if ignoredDirectories.contains(normalizedName) { enumerator.skipDescendants() }
                        indexed.append(SearchIndexEntry(root: root.path, path: url.path, normalizedPath: normalizedPath, name: url.lastPathComponent, normalizedName: normalizedName, ext: "", isDirectory: true, modifiedAt: values.contentModificationDate?.timeIntervalSince1970 ?? 0))
                    } else {
                        indexed.append(SearchIndexEntry(root: root.path, path: url.path, normalizedPath: normalizedPath, name: url.lastPathComponent, normalizedName: normalizedName, ext: url.pathExtension.lowercased(), isDirectory: false, modifiedAt: values.contentModificationDate?.timeIntervalSince1970 ?? 0))
                    }
                    if indexed.count.isMultiple(of: 5_000) {
                        SearchIndexStore.shared.publishProgress(root, entries: indexed)
                    }
                }
                SearchIndexStore.shared.finish(root, found: indexed)
            }
        }
    }

    static func needsSemanticRefinement(_ result: String) -> Bool {
        if result.hasPrefix("Busca local parcial") { return true }
        guard let firstLine = result.components(separatedBy: .newlines).first,
              let range = firstLine.range(of: #"\*\*(\d+) arquivos? encontrados?\*\*"#, options: .regularExpression),
              let _ = Int(firstLine[range].filter(\.isNumber)) else { return false }
        return firstLine.localizedCaseInsensitiveContains("busca parcial")
    }

    static func shouldUseSemanticSearch(query: String) -> Bool {
        let normalized = normalize(query)
        let contextual = ["parecido", "similar", "comparar", "compare", "contexto", "versao", "versoes", "mais recente", "mais novo", "aprovado", "referencia", "com base", "qual deles", "entre os"]
        return contextual.contains(where: normalized.contains) || words(normalized).subtracting(ignored).count >= 4
    }

    static let vectors: Set<String> = ["ai", "eps", "svg", "pdf"]
    static let aliases = ["levity": "poty", "roller": "poty", "push": "poty", "a9": "poty"]
    static let ignored: Set<String> = ["a", "o", "os", "as", "por", "favor", "pra", "quero", "pegue", "busque", "mostre", "ache", "me", "um", "uma", "de", "da", "do", "em", "para", "logo", "logos", "oficial", "atualizada", "atualizado", "vetor", "arquivo", "kv", "e"]
    static let kvExtensions: Set<String> = ["ai", "psd", "psb", "pdf", "eps", "png", "jpg", "jpeg", "indd"]
    static let keywords: Set<String> = ["logo", "logos", "marca", "marcas", "manual", "identidade"]
    private static let productVariants: Set<String> = ["cerveja", "beer", "pilsen", "malte", "rotulo", "rotulos", "garrafa", "garrafas", "lata", "latas"]
    private static let logoNameDescriptors: Set<String> = ["logo", "logos", "logotipo", "logotipos", "marca", "marcas", "oficial", "atualizada", "atualizado", "nova", "novo", "final", "vetor", "vetorial", "institucional", "horizontal", "vertical", "branca", "preta", "colorida", "rgb", "cmyk", "usar", "este", "v1", "v2", "v3", "cia", "companhia", "bebidas", "principal", "assinatura", "versao", "positiva", "negativa", "preto", "branco", "fundo", "transparente", "sem", "alta", "resolucao"]
    private static let logoAssetMarkers: Set<String> = ["logo", "logos", "marca", "marcas", "identidade", "brand", "branding"]
    private static let logoExtensions: Set<String> = ["ai", "eps", "svg", "pdf", "png", "jpg", "jpeg", "psd", "psb", "tif", "tiff"]
    private static let presentationTerms: Set<String> = ["apresentacao", "apresentacoes", "presentation", "presentations", "powerpoint", "ppt", "pptx", "keynote", "slideshow", "slides", "deck", "proposta", "propostas", "briefing", "relatorio", "relatorios", "catalogo", "catalogos"]

    /// Avoid treating a generic LOGOS directory as proof that every file is the requested client's logo.
    private static func conflictsWithRequestedBrand(nameWords: Set<String>, brandTerms: Set<String>, pathWords: Set<String>, queryWords: Set<String>) -> Bool {
        let hasRequestedBrandInName = !nameWords.isDisjoint(with: brandTerms)
        let hasUnrequestedName = !hasRequestedBrandInName && !nameWords.subtracting(logoNameDescriptors).isEmpty
        let unrequestedProductVariant = !pathWords.isDisjoint(with: productVariants) && queryWords.isDisjoint(with: productVariants)
        return hasUnrequestedName || unrequestedProductVariant
    }

    private static func isLogoAsset(nameWords: Set<String>, ext: String, parentComponents: [Set<String>], pathWords: Set<String>, brandTerms: Set<String>) -> Bool {
        guard logoExtensions.contains(ext), pathWords.isDisjoint(with: presentationTerms) else { return false }
        let hasRequestedBrand = !nameWords.isDisjoint(with: brandTerms) || parentComponents.contains { !$0.isDisjoint(with: brandTerms) }
        let hasLogoContext = !nameWords.isDisjoint(with: logoAssetMarkers) || parentComponents.contains { !$0.isDisjoint(with: logoAssetMarkers) }
        return hasRequestedBrand && hasLogoContext
    }

    static func words(_ text: String) -> Set<String> {
        Set(normalize(text).split(whereSeparator: { !$0.isLetter && !$0.isNumber }).map(String.init))
    }

    static func normalize(_ text: String) -> String {
        text.folding(options: [.caseInsensitive, .diacriticInsensitive], locale: Locale(identifier: "pt_BR")).lowercased()
    }

    static func card(_ url: URL, folder: Bool, size: String = "", reason: String = "") -> String {
        // JSON cards preserve quotes, braces and other valid filename characters.
        let fields = ["path": url.path, "name": url.lastPathComponent, "type": folder ? "folder" : url.pathExtension.lowercased(), "size": size, "reason": reason]
        guard let data = try? JSONEncoder().encode(fields) else { return "" }
        return ":::gravity-file:" + data.base64EncodedString() + ":::"
    }

    static func listDirectoryCards(folderPath: String, maxItems: Int = 28) -> String? {
        let url = URL(fileURLWithPath: folderPath)
        guard let entries = try? FileManager.default.contentsOfDirectory(at: url, includingPropertiesForKeys: [.isDirectoryKey], options: [.skipsHiddenFiles]) else { return nil }
        let sorted = entries.sorted { $0.lastPathComponent.localizedStandardCompare($1.lastPathComponent) == .orderedAscending }
        let cards = sorted.prefix(maxItems).map { entry in
            card(entry, folder: (try? entry.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) == true)
        }
        let count = entries.count > maxItems ? " · mostrando \(maxItems) de \(entries.count)" : ""
        return (["**\(url.lastPathComponent)**\(count)", url.path] + (cards.isEmpty ? ["Pasta vazia."] : cards)).joined(separator: "\n")
    }

    private static func preferredPotyLogoResults(roots: [URL], queryWords: Set<String>, wantedExtensions: Set<String>) -> String? {
        let fm = FileManager.default
        let vectors: Set<String> = ["ai", "eps", "svg", "pdf"]
        let brandTerms: Set<String> = ["poty"]
        let relativePaths = [
            "POTY/_LOGOS POTY/MARCAS ATUALIZADAS/Poty Cia de Bebidas",
            "POTY/_LOGOS POTY/Poty Cia de Bebidas"
        ]
        for root in roots {
            for relativePath in relativePaths {
                let directory = root.appendingPathComponent(relativePath, isDirectory: true)
                let readable = fm.isReadableFile(atPath: directory.path)
                guard readable,
                      let entries = try? fm.contentsOfDirectory(at: directory, includingPropertiesForKeys: nil, options: [.skipsHiddenFiles]) else { continue }
                var candidates: [(URL, Int, Date, String)] = []
                for url in entries {
                    let ext = url.pathExtension.lowercased()
                    guard logoExtensions.contains(ext), wantedExtensions.isEmpty || wantedExtensions.contains(ext) else { continue }
                    if !queryWords.isDisjoint(with: ["vetor", "vetorial"]) && !vectors.contains(ext) { continue }
                    let nameWords = words(url.deletingPathExtension().lastPathComponent)
                    let pathWords = words(url.path)
                    let parentComponents = url.deletingLastPathComponent().pathComponents.map(words)
                    guard !conflictsWithRequestedBrand(nameWords: nameWords, brandTerms: brandTerms, pathWords: pathWords, queryWords: queryWords),
                          isLogoAsset(nameWords: nameWords, ext: ext, parentComponents: parentComponents, pathWords: pathWords, brandTerms: brandTerms) else { continue }
                    let score = (vectors.contains(ext) ? 30 : 0) + (ext == "ai" ? 12 : 0)
                    candidates.append((url, score, .distantPast, "Identidade institucional atualizada da Poty"))
                }
                guard !candidates.isEmpty else { continue }
                candidates.sort {
                    if $0.1 != $1.1 { return $0.1 > $1.1 }
                    if $0.2 != $1.2 { return $0.2 > $1.2 }
                    return $0.0.path < $1.0.path
                }
                let countLabel = candidates.count == 1 ? "1 arquivo encontrado" : "\(candidates.count) arquivos encontrados"
                let cards = candidates.prefix(10).map { candidate in
                    return card(candidate.0, folder: false, reason: candidate.3)
                }
                return (["**\(countLabel)** · busca rápida"] + cards).joined(separator: "\n")
            }
        }
        return nil
    }

    static func tryInstantSearch(query: String, localOnly: Bool = false) -> String? {
        SearchIndexStore.shared.beginSearch()
        defer { SearchIndexStore.shared.endSearch() }
        let fm = FileManager.default
        let trimmed = query.trimmingCharacters(in: .whitespacesAndNewlines)
        let signpostID = OSSignpostID(log: SearchSignposts.log)
        os_signpost(.begin, log: SearchSignposts.log, name: "InstantSearch", signpostID: signpostID,
                    "queryLength=%{public}d localOnly=%{public}d", trimmed.utf8.count, localOnly ? 1 : 0)
        defer { os_signpost(.end, log: SearchSignposts.log, name: "InstantSearch", signpostID: signpostID) }
        if trimmed.hasPrefix("/") {
            guard GravityPaths.pathIsAuthorized(trimmed, roots: GravityPaths.searchRoots(localOnly: localOnly)) else { return nil }
            if let listing = listDirectoryCards(folderPath: trimmed) { return listing }
            var directory: ObjCBool = false
            if fm.fileExists(atPath: trimmed, isDirectory: &directory), !directory.boolValue {
                return card(URL(fileURLWithPath: trimmed), folder: false)
            }
            return nil
        }
        let q = normalize(trimmed)
        if q.contains("clientes servidor") || q.contains("pastas de clientes") || q == "clientes" {
            if !localOnly, GravityPaths.server.isEmpty {
                return "Servidor ainda não conectado. Conecte o compartilhamento no Finder e selecione a pasta em Ajustes → Pastas de pesquisa."
            }
            let serverResult = localOnly ? nil : listDirectoryCards(folderPath: GravityPaths.server)
            return serverResult ?? listDirectoryCards(folderPath: GravityPaths.local).map { "Pastas locais\n" + $0 }
        }

        var queryWords = words(q)
        let wantedExtensions = queryWords.intersection(["ai", "eps", "svg", "pdf", "png", "jpg", "jpeg", "psd", "psb", "aep", "mp4", "mov", "pptx", "docx"])
        let roots = GravityPaths.searchRoots(localOnly: localOnly)
        let rootSet = Set(roots.map { $0.standardizedFileURL.path })
        var terms = queryWords.subtracting(ignored).subtracting(wantedExtensions).subtracting(["atual", "pasta", "pastas", "abrir", "liste", "marca", "cliente", "clientes", "oficiais", "vetorial", "qual", "buscar", "encontre"])
        for term in terms.sorted() where term.count >= 4 {
            let correction = term == "porty" ? "poty" : SearchIndexStore.shared.correctedTerm(term, roots: rootSet)
            if let correction, correction != term {
                terms.remove(term)
                terms.insert(correction)
                queryWords.remove(term)
                queryWords.insert(correction)
            }
        }
        guard !terms.isEmpty else { return nil }
        let logo = !queryWords.isDisjoint(with: keywords) || !queryWords.isDisjoint(with: ["vetor", "vetorial"])
        let kv = queryWords.contains("kv")
        let annual = q.contains("anos") || q.contains("comemorativ")
        let logoSearchRoots = roots.sorted { $0.path == GravityPaths.server && $1.path != GravityPaths.server }
        if logo && terms == ["poty"], let preferred = preferredPotyLogoResults(roots: logoSearchRoots, queryWords: queryWords, wantedExtensions: wantedExtensions) {
            return preferred
        }
        startIndexing()
        if !queryWords.isDisjoint(with: ["pasta", "pastas", "diretorio", "diretorios"]), let folderResult = findMatchingFolders(terms: terms, roots: roots) {
            return folderResult
        }
        if let indexed = findIndexedFiles(query: q, terms: terms, queryWords: queryWords, wantedExtensions: wantedExtensions, roots: roots, logo: logo, kv: kv, annual: annual) {
            return indexed
        }
        // Keep scans serialized per storage source. The local fallback uses a
        // separate gate so a stalled network volume cannot block it.
        let scanGate = localOnly ? localScanGate : serverScanGate
        var acquiredScanGate = false
        while !Task.isCancelled {
            if scanGate.wait(timeout: .now() + .milliseconds(100)) == .success {
                acquiredScanGate = true
                break
            }
        }
        guard acquiredScanGate else { return nil }
        defer { scanGate.signal() }

        let serverConfigured = !GravityPaths.server.isEmpty
        let serverOnline = localOnly || (serverConfigured && fm.isReadableFile(atPath: GravityPaths.server))
        let approved = UserDefaults.standard.dictionary(forKey: "GravityApprovedFiles") as? [String: String] ?? [:]
        let deadline = ProcessInfo.processInfo.systemUptime + 1.25
        var timedOut = false
        var candidates: [(URL, Int, Date, String)] = []
        var candidateCount = 0
        var scannedTotal = 0
        var visited = Set<String>()

        let clientTerms = terms.union(terms.compactMap { aliases[$0] })
        let campaignOwner = terms.contains("fiduma") && terms.contains("jeca") ? "rede sol" : nil
        let blackFriday = campaignOwner != nil && terms.isSuperset(of: ["black", "friday"])
        let requiredTerms = blackFriday ? terms.subtracting(["friday", "jeca"]) : terms

        let fallbackRoots = roots.sorted { lhs, rhs in
            func priority(_ root: URL) -> Int {
                if queryWords.contains("desk"), root.lastPathComponent.localizedCaseInsensitiveContains("CLIENTES:DESK") { return 0 }
                if !localOnly && root.path == URL(fileURLWithPath: GravityPaths.server).standardizedFileURL.path { return 0 }
                if root.lastPathComponent.localizedCaseInsensitiveContains("CLIENTES:DESK") { return localOnly ? 0 : 1 }
                if root.path == URL(fileURLWithPath: GravityPaths.local).standardizedFileURL.path { return localOnly ? 2 : 3 }
                return 1
            }
            let left = priority(lhs), right = priority(rhs)
            return left == right ? lhs.path < rhs.path : left < right
        }
        for root in fallbackRoots {
            guard !Task.isCancelled, ProcessInfo.processInfo.systemUptime < deadline else { timedOut = true; break }
            guard let clients = try? fm.contentsOfDirectory(at: root, includingPropertiesForKeys: [.isDirectoryKey], options: [.skipsHiddenFiles]) else { continue }
            let matching = clients.filter {
                if let campaignOwner { return normalize($0.lastPathComponent) == campaignOwner }
                return !words($0.lastPathComponent).isDisjoint(with: clientTerms)
            }.sorted { $0.lastPathComponent.count < $1.lastPathComponent.count }
            if !logo && !kv && !matching.isEmpty && (queryWords.contains("pasta") || matching.contains(where: { words($0.lastPathComponent) == terms })) {
                let cards = matching.filter { (try? $0.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) == true }
                if !cards.isEmpty { return (["**Pastas encontradas**"] + cards.prefix(12).map { card($0, folder: true) }).joined(separator: "\n") }
            }
            let scopes = matching.isEmpty ? [root] : matching.prefix(maxScopes).flatMap { client -> [URL] in
                let children = (try? fm.contentsOfDirectory(at: client, includingPropertiesForKeys: [.isDirectoryKey], options: [.skipsHiddenFiles])) ?? []
                if logo {
                    let lookIn = [client] + children.filter { !words($0.lastPathComponent).isDisjoint(with: clientTerms) }
                    let branding = lookIn.flatMap {
                        (try? fm.contentsOfDirectory(at: $0, includingPropertiesForKeys: [.isDirectoryKey], options: [.skipsHiddenFiles])) ?? []
                    }.filter { !words($0.lastPathComponent).isDisjoint(with: keywords) }
                    let folders = branding.filter { (try? $0.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) == true }
                    let unique = Array(Set(folders)).sorted { $0.path < $1.path }
                    let preferredBrand: String?
                    if terms == ["poty"] { preferredBrand = "Poty Cia de Bebidas" }
                    else if terms == ["levity"] { preferredBrand = "Levity" }
                    else { preferredBrand = nil }
                    if let preferredBrand {
                        let preferred = unique.map {
                            normalize($0.lastPathComponent) == "marcas atualizadas"
                                ? $0.appendingPathComponent(preferredBrand, isDirectory: true)
                                : $0.appendingPathComponent("MARCAS ATUALIZADAS/" + preferredBrand, isDirectory: true)
                        }
                            .filter { fm.isReadableFile(atPath: $0.path) }
                        if !preferred.isEmpty { return preferred }
                    }
                    return unique.isEmpty ? [client] : unique
                }
                if blackFriday {
                    let campaigns = children.filter { $0.lastPathComponent.range(of: #"20[0-9]{2}$"#, options: .regularExpression) != nil }
                        .sorted { $0.lastPathComponent > $1.lastPathComponent }.prefix(4)
                        .map { $0.appendingPathComponent("CAMPANHAS/BLACK", isDirectory: true) }
                        .filter { fm.isReadableFile(atPath: $0.path) }
                    if !campaigns.isEmpty { return campaigns }
                }
                return children.filter {
                    !words($0.lastPathComponent).isDisjoint(with: terms.subtracting(words(client.lastPathComponent)))
                } + [client]
            }
            for scope in scopes.prefix(maxScopes) {
                guard !Task.isCancelled, scannedTotal < maxScannedEntries else {
                    timedOut = true
                    break
                }
                guard let entries = fm.enumerator(at: scope, includingPropertiesForKeys: [.isDirectoryKey, .isSymbolicLinkKey, .contentModificationDateKey], options: [.skipsHiddenFiles, .skipsPackageDescendants]) else { continue }
                while !Task.isCancelled {
                    guard ProcessInfo.processInfo.systemUptime < deadline, scannedTotal < maxScannedEntries else { timedOut = true; break }
                    guard let url = entries.nextObject() as? URL else { break }
                    scannedTotal += 1
                    guard let values = try? url.resourceValues(forKeys: [.isDirectoryKey, .isSymbolicLinkKey]) else { continue }
                    let name = normalize(url.deletingPathExtension().lastPathComponent)
                    if values.isSymbolicLink == true || values.isDirectory == true {
                        if values.isSymbolicLink == true || entries.level >= (matching.isEmpty ? 4 : 7) || name.contains("auto-save") || name.contains("salvamento automatico") || name == "1_ia's" { entries.skipDescendants() }
                        continue
                    }
                    let ext = url.pathExtension.lowercased()
                    guard !ext.isEmpty, wantedExtensions.isEmpty || wantedExtensions.contains(ext) else { continue }
                    if !queryWords.isDisjoint(with: ["vetor", "vetorial"]) && !vectors.contains(ext) { continue }
                    if kv && !kvExtensions.contains(ext) { continue }
                    let filename = words(name)
                    let path = String(url.path.dropFirst(root.path.count))
                    let pathTerms = words(path)
                    guard requiredTerms.isSubset(of: pathTerms) else { continue }
                    if pathTerms.contains("tmp") || normalize(path).contains("nao usar") { continue }
                    if logo && conflictsWithRequestedBrand(nameWords: filename, brandTerms: clientTerms, pathWords: pathTerms, queryWords: queryWords) { continue }
                    let parentComponents = url.deletingLastPathComponent().pathComponents.map(words)
                    if logo && !isLogoAsset(nameWords: filename, ext: ext, parentComponents: parentComponents, pathWords: pathTerms, brandTerms: clientTerms) { continue }
                    let brandInName = !filename.isDisjoint(with: clientTerms)
                    let hasBrandFolder = parentComponents.contains { !$0.isDisjoint(with: clientTerms) }
                    let hasLogoFolder = parentComponents.contains { !$0.isDisjoint(with: logoAssetMarkers) }
                    let brandFolder = hasBrandFolder && hasLogoFolder
                    let kvNamed = filename.contains("kv") || normalize(name).contains("key visual")
                    let kvFolder = url.deletingLastPathComponent().pathComponents.contains { words($0).contains("kv") || normalize($0).contains("key visual") }
                    if logo && !brandInName && !brandFolder { continue }
                    if logo && !annual && (pathTerms.contains("anos") || normalize(path).contains("comemorativ")) { continue }
                    if kv && !kvNamed && !kvFolder { continue }
                    if annual && !pathTerms.contains("anos") && !normalize(path).contains("comemorativ") { continue }
                    guard visited.insert(url.path).inserted else { continue }

                    var score = terms.intersection(filename).count * 30
                    var reason = "Nome ou pasta corresponde à busca"
                    if logo {
                        if brandInName { score += 35 }
                        if brandFolder { score += 45; reason = "Pasta de marcas" }
                        if vectors.contains(ext) { score += 30; reason += " · formato vetorial provável" }
                        if normalize(path).contains("marcas atualizadas") { score += 60 }
                        if words(name).contains("manual") { score -= 95 }
                        if ext == "ai" { score += 12 }
                        if normalize(name).contains("usar este") || normalize(name).contains("usar_este") {
                            score += 150
                            reason = "Arquivo identificado como «usar este»"
                        }
                        if terms == ["poty"] && normalize(path).contains("poty cia de bebidas") {
                            score += 130
                            reason = "Identidade institucional da Poty"
                        }
                        if !terms.intersection(filename).isEmpty { score += 40 }
                        if ["selo", "selos", "certificacao", "certificacoes", "qrcode", "rotulo", "rotulos", "mockup", "icones", "chancela"].contains(where: { pathTerms.contains($0) }) { score -= 120 }
                    }
                    if kvNamed { score += 80; reason = "KV identificado no nome" }
                    if kv && pathTerms.contains("aprovado") { score += 100; reason = "Pasta identificada como aprovada" }
                    if kv && ["ai", "psd", "psb", "indd"].contains(ext) { score += 15 }
                    if normalize(path).contains("antig") || normalize(path).contains("obsolet") || normalize(path).contains("desatualiz") { score -= 80 }
                    if approved[q] == url.path { score += 500; reason = "Referência aprovada" }
                    if root.path == GravityPaths.server { score += 5 }
                    let date = (try? url.resourceValues(forKeys: [.contentModificationDateKey]).contentModificationDate) ?? .distantPast
                    candidateCount += 1
                    candidates.append((url, score, date, reason))
                    candidates.sort {
                        if $0.1 != $1.1 { return $0.1 > $1.1 }
                        if $0.2 != $1.2 { return $0.2 > $1.2 }
                        return $0.0.path < $1.0.path
                    }
                    if candidates.count > maxRetainedCandidates {
                        candidates.removeLast(candidates.count - maxRetainedCandidates)
                    }
                }
            }
        }
        guard !candidates.isEmpty else {
            if timedOut { return "Busca local parcial. Refine com o cliente, a campanha ou o formato do arquivo." }
            if !serverConfigured && !localOnly { return "Servidor não conectado. Nenhum resultado nas pastas locais; conecte o compartilhamento no Finder e selecione a pasta em Ajustes." }
            if !serverOnline { return "Servidor indisponível. Nenhum resultado nas pastas locais." }
            return nil
        }
        let countLabel = candidateCount == 1 ? "1 arquivo encontrado" : "\(candidateCount) arquivos encontrados"
        let serverStatus = !serverConfigured && !localOnly ? " · servidor não conectado" : (!serverOnline ? " · servidor indisponível" : "")
        let title = "**\(countLabel)**" + (timedOut ? " · busca parcial" : "") + serverStatus
        return ([title] + candidates.prefix(10).map { card($0.0, folder: false, reason: $0.3) }).joined(separator: "\n")
    }

    private static func findMatchingFolders(terms: Set<String>, roots: [URL]) -> String? {
        guard !terms.isEmpty else { return nil }
        let rootSet = Set(roots.map { $0.standardizedFileURL.path })
        let entryGroups = SearchIndexStore.shared.entryGroups(matching: rootSet)
        var matches: [SearchIndexEntry] = []
        func ranksBefore(_ lhs: SearchIndexEntry, _ rhs: SearchIndexEntry) -> Bool {
            if lhs.path.count != rhs.path.count { return lhs.path.count < rhs.path.count }
            return lhs.path.localizedStandardCompare(rhs.path) == .orderedAscending
        }
        for entry in entryGroups.lazy.joined() where entry.isDirectory {
            guard terms.allSatisfy({ entry.normalizedPath.contains($0) }),
                  terms.isSubset(of: words(entry.normalizedPath)) else { continue }
            let insertionIndex = matches.firstIndex(where: { ranksBefore(entry, $0) }) ?? matches.endIndex
            if insertionIndex < 12 {
                matches.insert(entry, at: insertionIndex)
                if matches.count > 12 { matches.removeLast() }
            }
        }
        guard !matches.isEmpty else { return nil }
        return (["**Pastas encontradas**"] + matches.map { card(URL(fileURLWithPath: $0.path), folder: true) }).joined(separator: "\n")
    }

    private static func findIndexedFiles(query: String, terms: Set<String>, queryWords: Set<String>, wantedExtensions: Set<String>, roots: [URL], logo: Bool, kv: Bool, annual: Bool) -> String? {
        guard !terms.isEmpty else { return nil }
        let rootSet = Set(roots.map { $0.standardizedFileURL.path })
        let entryGroups = SearchIndexStore.shared.entryGroups(matching: rootSet)
        guard entryGroups.contains(where: { !$0.isEmpty }) else { return nil }
        let vectors: Set<String> = ["ai", "eps", "svg", "pdf"]
        let kvExtensions: Set<String> = ["ai", "psd", "psb", "pdf", "eps", "png", "jpg", "jpeg", "indd"]
        let approved = UserDefaults.standard.dictionary(forKey: "GravityApprovedFiles") as? [String: String] ?? [:]
        var matches: [(SearchIndexEntry, Int, String)] = []
        var matchCount = 0
        func ranksBefore(_ lhs: (SearchIndexEntry, Int, String), _ rhs: (SearchIndexEntry, Int, String)) -> Bool {
            if lhs.1 != rhs.1 { return lhs.1 > rhs.1 }
            if lhs.0.modifiedAt != rhs.0.modifiedAt { return lhs.0.modifiedAt > rhs.0.modifiedAt }
            return lhs.0.path < rhs.0.path
        }
        for entry in entryGroups.lazy.joined() where !entry.isDirectory {
            let ext = entry.ext
            guard !ext.isEmpty, wantedExtensions.isEmpty || wantedExtensions.contains(ext) else { continue }
            if !queryWords.isDisjoint(with: ["vetor", "vetorial"]) && !vectors.contains(ext) { continue }
            if kv && !kvExtensions.contains(ext) { continue }
            // Cheap substring rejection avoids building token sets for every indexed path.
            guard terms.allSatisfy({ entry.normalizedPath.contains($0) }) else { continue }
            let pathWords = words(entry.normalizedPath)
            guard terms.isSubset(of: pathWords) else { continue }
            if pathWords.contains("tmp") || entry.normalizedPath.contains("nao usar") { continue }
            let nameWords = words(entry.normalizedName)
            if logo && conflictsWithRequestedBrand(nameWords: nameWords, brandTerms: terms.union(terms.compactMap { aliases[$0] }), pathWords: pathWords, queryWords: queryWords) { continue }
            let brandTerms = terms.union(terms.compactMap { aliases[$0] })
            let parentComponents = URL(fileURLWithPath: entry.path).deletingLastPathComponent().pathComponents.map(words)
            if logo && !isLogoAsset(nameWords: nameWords, ext: ext, parentComponents: parentComponents, pathWords: pathWords, brandTerms: brandTerms) { continue }
            let brandInName = !nameWords.isDisjoint(with: brandTerms)
            let hasBrandFolder = parentComponents.contains { !$0.isDisjoint(with: brandTerms) }
            let hasLogoFolder = parentComponents.contains { !$0.isDisjoint(with: logoAssetMarkers) }
            let brandFolder = hasBrandFolder && hasLogoFolder
            let kvNamed = nameWords.contains("kv") || entry.normalizedName.contains("key visual")
            let kvFolder = URL(fileURLWithPath: entry.path).deletingLastPathComponent().pathComponents.contains { words($0).contains("kv") || normalize($0).contains("key visual") }
            if logo && !brandInName && !brandFolder { continue }
            if logo && !annual && (pathWords.contains("anos") || entry.normalizedPath.contains("comemorativ")) { continue }
            if kv && !kvNamed && !kvFolder { continue }
            if annual && !pathWords.contains("anos") && !entry.normalizedPath.contains("comemorativ") { continue }

            var score = terms.intersection(nameWords).count * 30
            var reason = "Nome ou pasta corresponde à busca"
            if logo {
                if brandInName { score += 35 }
                if brandFolder { score += 45; reason = "Pasta de marcas" }
                if vectors.contains(ext) { score += 30; reason += " · formato vetorial provável" }
                if entry.normalizedPath.contains("marcas atualizadas") { score += 60; reason = "Marca atualizada" }
                if nameWords.contains("manual") { score -= 95 }
                if ext == "ai" { score += 12 }
                if entry.normalizedName.contains("usar este") || entry.normalizedName.contains("usar_este") { score += 150; reason = "Arquivo identificado como usar este" }
                if terms == ["poty"] && entry.normalizedPath.contains("poty cia de bebidas") { score += 130; reason = "Identidade institucional da Poty" }
                if ["selo", "selos", "certificacao", "certificacoes", "qrcode", "rotulo", "rotulos", "mockup", "icones", "chancela"].contains(where: { pathWords.contains($0) }) { score -= 120 }
            }
            if kvNamed { score += 80; reason = "KV identificado no nome" }
            if kv && pathWords.contains("aprovado") { score += 100; reason = "Pasta identificada como aprovada" }
            if kv && ["ai", "psd", "psb", "indd"].contains(ext) { score += 15 }
            if entry.normalizedPath.contains("antig") || entry.normalizedPath.contains("obsolet") || entry.normalizedPath.contains("desatualiz") { score -= 80 }
            if GravityPaths.server == entry.root { score += 5 }
            if approved[query] == entry.path { score += 500; reason = "Referência aprovada" }
            matchCount += 1
            let candidate = (entry, score, reason)
            if matches.count < 10 {
                matches.append(candidate)
                matches.sort(by: ranksBefore)
            } else if let last = matches.last, ranksBefore(candidate, last) {
                matches[matches.count - 1] = candidate
                matches.sort(by: ranksBefore)
            }
        }
        if logo && terms == ["poty"] {
            let institutional = matches.filter {
                $0.0.normalizedPath.contains("marcas atualizadas") && $0.0.normalizedPath.contains("poty cia de bebidas")
            }
            if !institutional.isEmpty {
                matches = institutional
                matchCount = institutional.count
            }
        }
        guard !matches.isEmpty else { return nil }
        let cards = matches.prefix(10).map { entry, _, reason in
            let url = URL(fileURLWithPath: entry.path)
            let size = ((try? url.resourceValues(forKeys: [.fileSizeKey]).fileSize).map(String.init)) ?? ""
            return card(url, folder: false, size: size, reason: reason)
        }
        let countLabel = matchCount == 1 ? "1 arquivo encontrado" : "\(matchCount) arquivos encontrados"
        let title = "**\(countLabel)** · busca rápida"
        return ([title] + cards).joined(separator: "\n")
    }
}

