import Foundation
import os

enum SearchSignposts {
    static let log = OSLog(
        subsystem: Bundle.main.bundleIdentifier ?? "com.gravity.assistente",
        category: "Search"
    )
}

enum GravityPaths {
    static let home = FileManager.default.homeDirectoryForCurrentUser
    static let defaults = UserDefaults.standard
    static var server: String { defaults.string(forKey: "GravityServer") ?? "" }
    static var local: String { defaults.string(forKey: "GravityLocal") ?? home.appendingPathComponent("Documents").path }
    static var work: String { defaults.string(forKey: "GravityWork") ?? local + "/1_IA's" }
    static var agy: String { defaults.string(forKey: "GravityCLI") ?? home.appendingPathComponent(".local/bin/agy").path }
    static var brain: String { home.appendingPathComponent(".gemini/antigravity-cli/brain").path }
    static var legacyHistory: String { work + "/ANTIGRAVITY/Assistente Gravity/conversations.json" }
    static var history: String {
        if let configured = defaults.string(forKey: "GravityHistory") { return configured }
        if Bundle.main.bundleIdentifier?.hasSuffix(".preview") != true, FileManager.default.fileExists(atPath: legacyHistory) { return legacyHistory }
        let appName = Bundle.main.bundleIdentifier?.hasSuffix(".preview") == true
            ? "Assistente Gravity Preview"
            : "Assistente Gravity"
        return home.appendingPathComponent("Library/Application Support/\(appName)/conversations.json").path
    }

    static var searchIndex: URL {
        let appName = Bundle.main.bundleIdentifier?.hasSuffix(".preview") == true ? "Assistente Gravity Preview" : "Assistente Gravity"
        return home.appendingPathComponent("Library/Application Support/\(appName)/search-index.plist")
    }

    static func searchRoots(localOnly: Bool = false) -> [URL] {
        let fm = FileManager.default
        let authorizedFolders = defaults.stringArray(forKey: "GravityAuthorizedFolders") ?? []
        var paths = [local] + authorizedFolders
        if !localOnly, !server.isEmpty { paths.append(server) }
        var seen = Set<String>()
        return paths.compactMap { path in
            let normalized = URL(fileURLWithPath: path).standardizedFileURL.resolvingSymlinksInPath().path
            if seen.contains(where: { normalized.hasPrefix($0.hasSuffix("/") ? $0 : $0 + "/") }) { return nil }
            guard seen.insert(normalized).inserted, fm.isReadableFile(atPath: normalized) else { return nil }
            return URL(fileURLWithPath: normalized, isDirectory: true)
        }
    }

    static func pathIsAuthorized(_ path: String, roots: [URL] = searchRoots()) -> Bool {
        let candidate = URL(fileURLWithPath: path).standardizedFileURL.resolvingSymlinksInPath().path
        return roots.contains { root in
            let rootPath = root.standardizedFileURL.resolvingSymlinksInPath().path
            return candidate == rootPath || candidate.hasPrefix(rootPath.hasSuffix("/") ? rootPath : rootPath + "/")
        }
    }
}

struct SearchIndexEntry: Codable, Sendable {
    let root: String
    let path: String
    let normalizedPath: String
    let name: String
    let normalizedName: String
    let ext: String
    let isDirectory: Bool
    let modifiedAt: TimeInterval
}

private struct SearchIndexSnapshot: Codable {
    let version: Int
    let indexedAt: [String: TimeInterval]
    let entries: [SearchIndexEntry]
}

final class SearchIndexStore: @unchecked Sendable {
    static let shared = SearchIndexStore()
    private static let persistenceQueue = DispatchQueue(label: "gravity.search-index.persistence", qos: .utility)
    private let lock = NSLock()
    private var entriesByRoot: [String: [SearchIndexEntry]] = [:]
    private var indexedAt: [String: TimeInterval] = [:]
    private var indexingRoots = Set<String>()
    private var completedRoots = Set<String>()
    private var activeSearches = 0
    // Keep enough room for the SMB root after local and authorized folders.
    // A single global 250k cap let earlier roots consume the entire index and
    // still marked a zero-entry server root as recently indexed.
    private let maxEntries = 500_000
    private let reservedServerEntries = 200_000

    private init() {
        let destination = GravityPaths.searchIndex
        let legacyJSON = destination.deletingPathExtension().appendingPathExtension("json")
        let data = (try? Data(contentsOf: destination)) ?? (try? Data(contentsOf: legacyJSON))
        guard let data,
              let snapshot = (try? PropertyListDecoder().decode(SearchIndexSnapshot.self, from: data))
                ?? (try? JSONDecoder().decode(SearchIndexSnapshot.self, from: data)),
              snapshot.version == 1 else { return }
        for entry in snapshot.entries {
            entriesByRoot[entry.root, default: []].append(entry)
        }
        indexedAt = snapshot.indexedAt
        completedRoots = Set(snapshot.indexedAt.keys)
        if !FileManager.default.fileExists(atPath: destination.path) {
            DispatchQueue.global(qos: .utility).async {
                Self.write(snapshot, to: destination)
            }
        }
    }

    func entryGroups(matching roots: Set<String>) -> [[SearchIndexEntry]] {
        lock.lock(); defer { lock.unlock() }
        return roots.sorted().compactMap { entriesByRoot[$0] }
    }

    func retainEntries(for roots: Set<String>) {
        lock.lock()
        let previousRootCount = entriesByRoot.count
        let previousIndexCount = indexedAt.count
        entriesByRoot = entriesByRoot.filter { roots.contains($0.key) }
        indexedAt = indexedAt.filter { roots.contains($0.key) }
        completedRoots = completedRoots.intersection(roots)
        guard previousRootCount != entriesByRoot.count || previousIndexCount != indexedAt.count else {
            lock.unlock()
            return
        }
        let snapshot = SearchIndexSnapshot(version: 1, indexedAt: indexedAt, entries: entriesByRoot.values.flatMap { $0 })
        lock.unlock()

        Self.write(snapshot, to: GravityPaths.searchIndex)
    }

    func beginSearch() {
        lock.lock(); activeSearches += 1; lock.unlock()
    }

    func endSearch() {
        lock.lock(); activeSearches = max(0, activeSearches - 1); lock.unlock()
    }

    func shouldPauseIndexing() -> Bool {
        lock.lock(); defer { lock.unlock() }
        return activeSearches > 0
    }

    // A full walk of a mounted SMB share is expensive. Refresh periodically,
    // while missing search results can still use the bounded live-scan fallback.
    func rootsNeedingRefresh(_ roots: [URL], maxAge: TimeInterval = 6 * 60 * 60) -> [URL] {
        lock.lock(); defer { lock.unlock() }
        let now = Date().timeIntervalSince1970
        return roots.filter { root in
            let path = root.standardizedFileURL.path
            let hasEntries = !(entriesByRoot[path]?.isEmpty ?? true)
            return !indexingRoots.contains(path)
                && (!hasEntries || now - (indexedAt[path] ?? 0) > maxAge)
        }
    }

    func capacity(replacing root: URL) -> Int {
        lock.lock(); defer { lock.unlock() }
        let rootPath = root.standardizedFileURL.path
        let retainedCount = entriesByRoot.reduce(into: 0) { count, item in
            if item.key != rootPath { count += item.value.count }
        }
        let serverPath = URL(fileURLWithPath: GravityPaths.server).standardizedFileURL.path
        let reserve = !GravityPaths.server.isEmpty && rootPath != serverPath ? reservedServerEntries : 0
        return max(0, maxEntries - retainedCount - reserve)
    }

    func publishProgress(_ root: URL, entries: [SearchIndexEntry]) {
        lock.lock()
        let path = root.standardizedFileURL.path
        // Keep the old complete snapshot until a refresh finishes. For a new
        // root, expose batches so searches can use the growing index immediately.
        if !completedRoots.contains(path) { entriesByRoot[path] = entries }
        lock.unlock()
    }

    func begin(_ root: URL) -> Bool {
        lock.lock(); defer { lock.unlock() }
        let path = root.standardizedFileURL.path
        guard indexingRoots.insert(path).inserted else { return false }
        if entriesByRoot[path]?.isEmpty ?? true { completedRoots.remove(path) }
        return true
    }

    func finish(_ root: URL, found entriesForRoot: [SearchIndexEntry]) {
        lock.lock()
        let path = root.standardizedFileURL.path
        let retainedCount = entriesByRoot.reduce(into: 0) { count, item in
            if item.key != path { count += item.value.count }
        }
        entriesByRoot[path] = Array(entriesForRoot.prefix(max(0, maxEntries - retainedCount)))
        indexedAt[path] = Date().timeIntervalSince1970
        completedRoots.insert(path)
        indexingRoots.remove(path)
        let snapshot = SearchIndexSnapshot(version: 1, indexedAt: indexedAt, entries: entriesByRoot.values.flatMap { $0 })
        lock.unlock()

        Self.write(snapshot, to: GravityPaths.searchIndex)
    }

    private static func write(_ snapshot: SearchIndexSnapshot, to destination: URL) {
        persistenceQueue.async {
            let encoder = PropertyListEncoder()
            encoder.outputFormat = .binary
            guard let data = try? encoder.encode(snapshot) else { return }
            try? FileManager.default.createDirectory(at: destination.deletingLastPathComponent(), withIntermediateDirectories: true)
            try? data.write(to: destination, options: .atomic)
        }
    }

    func fail(_ root: URL) {
        lock.lock(); indexingRoots.remove(root.standardizedFileURL.path); lock.unlock()
    }
}
