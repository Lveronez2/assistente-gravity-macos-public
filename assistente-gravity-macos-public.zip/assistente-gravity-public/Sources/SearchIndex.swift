import Foundation
import os

enum SearchSignposts {
    static let log = OSLog(
        subsystem: Bundle.main.bundleIdentifier ?? "com.gravity.assistente",
        category: "Search"
    )
}

enum GravityPaths {
    static let home = FileManager.default.homeDirectoryForCurrentUser
    static let defaults = UserDefaults.standard
    static var server: String { defaults.string(forKey: "GravityServer") ?? "" }
    static var local: String { defaults.string(forKey: "GravityLocal") ?? home.appendingPathComponent("Documents").path }
    static var work: String { defaults.string(forKey: "GravityWork") ?? local + "/1_IA's" }
    static var agy: String { defaults.string(forKey: "GravityCLI") ?? home.appendingPathComponent(".local/bin/agy").path }
    static var brain: String { home.appendingPathComponent(".gemini/antigravity-cli/brain").path }
    static var legacyHistory: String { work + "/ANTIGRAVITY/Assistente Gravity/conversations.json" }
    static var history: String {
        if let configured = defaults.string(forKey: "GravityHistory") { return configured }
        if Bundle.main.bundleIdentifier?.hasSuffix(".preview") != true, FileManager.default.fileExists(atPath: legacyHistory) { return legacyHistory }
        let appName = Bundle.main.bundleIdentifier?.hasSuffix(".preview") == true
            ? "Assistente Gravity Preview"
            : "Assistente Gravity"
        return home.appendingPathComponent("Library/Application Support/\(appName)/conversations.json").path
    }

    static var searchIndex: URL {
        let appName = Bundle.main.bundleIdentifier?.hasSuffix(".preview") == true ? "Assistente Gravity Preview" : "Assistente Gravity"
        return home.appendingPathComponent("Library/Application Support/\(appName)/search-index.plist")
    }

    static func searchRoots(localOnly: Bool = false) -> [URL] {
        let fm = FileManager.default
        let authorizedFolders = defaults.stringArray(forKey: "GravityAuthorizedFolders") ?? []
        var paths = [local] + authorizedFolders
        if !localOnly, !server.isEmpty { paths.append(server) }
        var seen = Set<String>()
        return paths.compactMap { path in
            let normalized = URL(fileURLWithPath: path).standardizedFileURL.resolvingSymlinksInPath().path
            if seen.contains(where: { normalized.hasPrefix($0.hasSuffix("/") ? $0 : $0 + "/") }) { return nil }
            guard seen.insert(normalized).inserted, fm.isReadableFile(atPath: normalized) else { return nil }
            return URL(fileURLWithPath: normalized, isDirectory: true)
        }
    }

    static func pathIsAuthorized(_ path: String, roots: [URL] = searchRoots()) -> Bool {
        let candidate = URL(fileURLWithPath: path).standardizedFileURL.resolvingSymlinksInPath().path
        return roots.contains { root in
            let rootPath = root.standardizedFileURL.resolvingSymlinksInPath().path
            return candidate == rootPath || candidate.hasPrefix(rootPath.hasSuffix("/") ? rootPath : rootPath + "/")
        }
    }
}

enum GravityCLISettings {
    /// Give each search read access only to the folders selected in Gravity.
    /// File search can use sandboxed read commands inside the selected roots;
    /// writes, MCP actions and network access remain denied.
    static func json(readableRoots: [URL], webResearch: Bool) -> String {
        let paths = Set(readableRoots.map { $0.standardizedFileURL.resolvingSymlinksInPath().path })
        let allow = webResearch ? [] : paths.sorted()
            .filter { !$0.contains(")") && !$0.contains("\n") }
            .map { "read_file(\($0))" }
        var deny = ["write_file(*)", "mcp(*)", "read_url(*)", "execute_url(*)", "download_url(*)"]
        if webResearch {
            deny.append("read_file(*)")
            deny.append("command(*)")
        }
        let settings: [String: Any] = [
            "permissions": ["allow": allow, "ask": [String](), "deny": deny]
        ]
        guard let data = try? JSONSerialization.data(withJSONObject: settings, options: [.sortedKeys]),
              let json = String(data: data, encoding: .utf8) else {
            return #"{"permissions":{"allow":[],"ask":[],"deny":["*"]}}"#
        }
        return json
    }
}

struct SearchIndexEntry: Codable, Sendable {
    let root: String
    let path: String
    let normalizedPath: String
    let name: String
    let normalizedName: String
    let ext: String
    let isDirectory: Bool
    let modifiedAt: TimeInterval
}

private struct SearchIndexSnapshot: Codable {
    let version: Int
    let indexedAt: [String: TimeInterval]
    let entries: [SearchIndexEntry]
}

final class SearchIndexStore: @unchecked Sendable {
    static let shared = SearchIndexStore()
    private static let persistenceQueue = DispatchQueue(label: "gravity.search-index.persistence", qos: .utility)
    private let lock = NSLock()
    private var entriesByRoot: [String: [SearchIndexEntry]] = [:]
    private var vocabularyByRoot: [String: [Int: [String: Int]]] = [:]
    private var indexedAt: [String: TimeInterval] = [:]
    private var indexingRoots = Set<String>()
    private var completedRoots = Set<String>()
    private var activeSearches = 0
    // Keep enough room for the SMB root after local and authorized folders.
    // A single global 250k cap let earlier roots consume the entire index and
    // still marked a zero-entry server root as recently indexed.
    private let maxEntries = 500_000
    private let reservedServerEntries = 200_000

    private init() {
        let destination = GravityPaths.searchIndex
        let legacyJSON = destination.deletingPathExtension().appendingPathExtension("json")
        let data = (try? Data(contentsOf: destination)) ?? (try? Data(contentsOf: legacyJSON))
        guard let data,
              let snapshot = (try? PropertyListDecoder().decode(SearchIndexSnapshot.self, from: data))
                ?? (try? JSONDecoder().decode(SearchIndexSnapshot.self, from: data)),
              snapshot.version == 1 else { return }
        for entry in snapshot.entries {
            entriesByRoot[entry.root, default: []].append(entry)
        }
        let savedEntries = entriesByRoot
        DispatchQueue.global(qos: .utility).async { [weak self] in
            let vocabulary = Self.makeVocabulary(savedEntries)
            self?.lock.lock()
            self?.vocabularyByRoot = vocabulary
            self?.lock.unlock()
        }
        indexedAt = snapshot.indexedAt
        completedRoots = Set(snapshot.indexedAt.keys)
        if !FileManager.default.fileExists(atPath: destination.path) {
            DispatchQueue.global(qos: .utility).async {
                Self.write(snapshot, to: destination)
            }
        }
    }

    func entryGroups(matching roots: Set<String>) -> [[SearchIndexEntry]] {
        lock.lock(); defer { lock.unlock() }
        return roots.sorted().compactMap { entriesByRoot[$0] }
    }

    func correctedTerm(_ term: String, roots: Set<String>) -> String? {
        lock.lock(); defer { lock.unlock() }
        if roots.contains(where: { vocabularyByRoot[$0]?[term.count]?[term] != nil }) { return nil }
        let candidates = roots.reduce(into: [String: Int]()) { result, root in
            for (length, bucket) in vocabularyByRoot[root] ?? [:] where abs(length - term.count) <= 1 {
                for (word, frequency) in bucket where Self.isOneEditAway(term, word) { result[word, default: 0] += frequency }
            }
        }
        guard let best = candidates.max(by: { $0.value < $1.value }), best.value >= 2 else { return nil }
        let tied = candidates.values.filter { $0 == best.value }.count > 1
        return tied ? nil : best.key
    }

    private static func makeVocabulary(_ entriesByRoot: [String: [SearchIndexEntry]]) -> [String: [Int: [String: Int]]] {
        var result: [String: [Int: [String: Int]]] = [:]
        for (root, entries) in entriesByRoot {
            var vocabulary: [String: Int] = [:]
            for entry in entries where !entry.isDirectory {
                for token in Set(entry.normalizedName.split(whereSeparator: { !$0.isLetter && !$0.isNumber }).map(String.init)
                    + entry.normalizedPath.split(whereSeparator: { !$0.isLetter && !$0.isNumber }).map(String.init)) {
                    vocabulary[token, default: 0] += 1
                }
            }
            result[root] = Dictionary(grouping: vocabulary.keys, by: \.count).mapValues { tokens in
                Dictionary(uniqueKeysWithValues: tokens.map { ($0, vocabulary[$0] ?? 0) })
            }
        }
        return result
    }

    private static func isOneEditAway(_ lhs: String, _ rhs: String) -> Bool {
        let a = Array(lhs), b = Array(rhs)
        guard abs(a.count - b.count) <= 1, a != b else { return false }
        if a.count == b.count {
            let differences = zip(a, b).enumerated().filter { $0.element.0 != $0.element.1 }.map(\.offset)
            if differences.count == 2, differences[1] == differences[0] + 1 {
                return a[differences[0]] == b[differences[1]] && a[differences[1]] == b[differences[0]]
            }
            return differences.count == 1
        }
        let shorter = a.count < b.count ? a : b
        let longer = a.count < b.count ? b : a
        var i = 0, j = 0, skipped = false
        while i < shorter.count && j < longer.count {
            if shorter[i] == longer[j] { i += 1; j += 1 }
            else if skipped { return false }
            else { skipped = true; j += 1 }
        }
        return true
    }

    func retainEntries(for roots: Set<String>) {
        lock.lock()
        let previousRootCount = entriesByRoot.count
        let previousIndexCount = indexedAt.count
        entriesByRoot = entriesByRoot.filter { roots.contains($0.key) }
        vocabularyByRoot = vocabularyByRoot.filter { roots.contains($0.key) }
        indexedAt = indexedAt.filter { roots.contains($0.key) }
        completedRoots = completedRoots.intersection(roots)
        guard previousRootCount != entriesByRoot.count || previousIndexCount != indexedAt.count else {
            lock.unlock()
            return
        }
        let snapshot = SearchIndexSnapshot(version: 1, indexedAt: indexedAt, entries: entriesByRoot.values.flatMap { $0 })
        lock.unlock()

        Self.write(snapshot, to: GravityPaths.searchIndex)
    }

    func beginSearch() {
        lock.lock(); activeSearches += 1; lock.unlock()
    }

    func endSearch() {
        lock.lock(); activeSearches = max(0, activeSearches - 1); lock.unlock()
    }

    func shouldPauseIndexing() -> Bool {
        lock.lock(); defer { lock.unlock() }
        return activeSearches > 0
    }

    // A full walk of a mounted SMB share is expensive. Refresh periodically,
    // while missing search results can still use the bounded live-scan fallback.
    func rootsNeedingRefresh(_ roots: [URL], maxAge: TimeInterval = 6 * 60 * 60) -> [URL] {
        lock.lock(); defer { lock.unlock() }
        let now = Date().timeIntervalSince1970
        return roots.filter { root in
            let path = root.standardizedFileURL.path
            let hasEntries = !(entriesByRoot[path]?.isEmpty ?? true)
            return !indexingRoots.contains(path)
                && (!hasEntries || now - (indexedAt[path] ?? 0) > maxAge)
        }
    }

    func capacity(replacing root: URL) -> Int {
        lock.lock(); defer { lock.unlock() }
        let rootPath = root.standardizedFileURL.path
        let retainedCount = entriesByRoot.reduce(into: 0) { count, item in
            if item.key != rootPath { count += item.value.count }
        }
        let serverPath = URL(fileURLWithPath: GravityPaths.server).standardizedFileURL.path
        let reserve = !GravityPaths.server.isEmpty && rootPath != serverPath ? reservedServerEntries : 0
        return max(0, maxEntries - retainedCount - reserve)
    }

    func publishProgress(_ root: URL, entries: [SearchIndexEntry]) {
        lock.lock()
        let path = root.standardizedFileURL.path
        // Keep the old complete snapshot until a refresh finishes. For a new
        // root, expose batches so searches can use the growing index immediately.
        if !completedRoots.contains(path) { entriesByRoot[path] = entries }
        lock.unlock()
    }

    func begin(_ root: URL) -> Bool {
        lock.lock(); defer { lock.unlock() }
        let path = root.standardizedFileURL.path
        guard indexingRoots.insert(path).inserted else { return false }
        if entriesByRoot[path]?.isEmpty ?? true { completedRoots.remove(path) }
        return true
    }

    func finish(_ root: URL, found entriesForRoot: [SearchIndexEntry]) {
        lock.lock()
        let path = root.standardizedFileURL.path
        let retainedCount = entriesByRoot.reduce(into: 0) { count, item in
            if item.key != path { count += item.value.count }
        }
        entriesByRoot[path] = Array(entriesForRoot.prefix(max(0, maxEntries - retainedCount)))
        vocabularyByRoot[path] = Self.makeVocabulary([path: entriesByRoot[path] ?? []])[path]
        indexedAt[path] = Date().timeIntervalSince1970
        completedRoots.insert(path)
        indexingRoots.remove(path)
        let snapshot = SearchIndexSnapshot(version: 1, indexedAt: indexedAt, entries: entriesByRoot.values.flatMap { $0 })
        lock.unlock()

        Self.write(snapshot, to: GravityPaths.searchIndex)
    }

    private static func write(_ snapshot: SearchIndexSnapshot, to destination: URL) {
        persistenceQueue.async {
            let encoder = PropertyListEncoder()
            encoder.outputFormat = .binary
            guard let data = try? encoder.encode(snapshot) else { return }
            try? FileManager.default.createDirectory(at: destination.deletingLastPathComponent(), withIntermediateDirectories: true)
            try? data.write(to: destination, options: .atomic)
        }
    }

    func fail(_ root: URL) {
        lock.lock(); indexingRoots.remove(root.standardizedFileURL.path); lock.unlock()
    }
}
