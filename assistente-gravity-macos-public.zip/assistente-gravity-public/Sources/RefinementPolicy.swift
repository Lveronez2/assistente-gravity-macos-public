import Foundation

/// Monotonic deadlines distinguish a stalled CLI from an active search.
struct RefinementWatchdog {
    let startedAt: TimeInterval
    private(set) var lastActivityAt: TimeInterval
    let idleLimit: TimeInterval
    let totalLimit: TimeInterval

    init(now: TimeInterval, idleLimit: TimeInterval = 90, totalLimit: TimeInterval = 300) {
        startedAt = now
        lastActivityAt = now
        self.idleLimit = idleLimit
        self.totalLimit = totalLimit
    }

    mutating func noteActivity(at now: TimeInterval) { lastActivityAt = max(lastActivityAt, now) }

    func timeoutReason(at now: TimeInterval) -> String? {
        if now - startedAt >= totalLimit { return "O refinamento atingiu o limite de cinco minutos." }
        if now - lastActivityAt >= idleLimit { return "O serviço de busca ficou 90 segundos sem responder." }
        return nil
    }
}

enum RefinementRecovery {
    static func hasFiles(_ text: String) -> Bool {
        text.contains(":::gravity-file:") || text.contains(":::file-card{")
    }

    static func message(local: String?, partial: String?, reason: String) -> String {
        if let local, hasFiles(local) { return local }
        let explanation = "A busca não pôde ser concluída agora. \(reason) Use Tentar novamente ou informe o nome do cliente e o formato da logo."
        if let partial, !partial.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            return "Resposta parcial do refinamento:\n\(partial)\n\n\(explanation)"
        }
        return explanation
    }

    static func streaming(local: String?, partial: String) -> String {
        guard let local, hasFiles(local) else { return partial }
        return partial.isEmpty ? local : local + "\n\nRefinamento em andamento:\n" + partial
    }
}
