import Cocoa
import SwiftUI
import QuartzCore

// MARK: - Painel Flutuante Nativo

final class InteractiveFloatingPanel: NSPanel {
    override var canBecomeKey: Bool { true }
    override var canBecomeMain: Bool { true }
}

@MainActor
private final class GravityHostingView: NSHostingView<GravityRootView> {
    private var lockedAppearance: NSAppearance?

    func lockAppearance(_ appearance: NSAppearance) {
        lockedAppearance = appearance
        self.appearance = appearance
    }

    override func viewDidChangeEffectiveAppearance() {
        super.viewDidChangeEffectiveAppearance()
        guard let lockedAppearance, self.appearance?.name != lockedAppearance.name else { return }
        self.appearance = lockedAppearance
    }
}

@MainActor
final class WindowCoordinator: NSObject, NSApplicationDelegate, NSWindowDelegate {
    var window: InteractiveFloatingPanel!
    var viewModel: GravityViewModel!
    private var hostingView: GravityHostingView?

    let bubbleSize = CGSize(width: 110, height: 110)
    let quickSize = CGSize(width: 560, height: 480)
    let setupSize = CGSize(width: 560, height: 560)
    let matrixSize = CGSize(width: 820, height: 540)

    private var pointerGesture = WindowPointerGesture()
    private var dragAnchorOffset: NSPoint = .zero
    private var mouseMonitors: [Any] = []
    private var reduceMotionEnabled = false
    private var transitionGeneration = UUID()

    func applicationDidFinishLaunching(_ notification: Notification) {
        viewModel = GravityViewModel()
        viewModel.windowController = self

        let screen = NSScreen.main?.visibleFrame ?? NSRect(x: 0, y: 0, width: 1440, height: 900)
        let initialRect = NSRect(
            x: screen.maxX - bubbleSize.width - 28,
            y: screen.maxY - bubbleSize.height - 28,
            width: bubbleSize.width,
            height: bubbleSize.height
        )

        window = InteractiveFloatingPanel(
            contentRect: initialRect,
            styleMask: [.borderless, .nonactivatingPanel],
            backing: .buffered,
            defer: false
        )
        window.level = .floating
        window.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary]
        window.isOpaque = false
        window.backgroundColor = .clear
        window.hasShadow = false
        window.isMovableByWindowBackground = false
        window.delegate = self
        applyAppearance()

        if #available(macOS 26.0, *) {
            let rootView = GravityRootView(vm: viewModel)
            let hosting = GravityHostingView(rootView: rootView)
            // Keep SwiftUI's ideal size from resizing this floating panel.
            // Flexible setup content includes a Spacer and must stay inside
            // the explicit quick-panel frame instead of expanding to the screen.
            hosting.sizingOptions = []
            hosting.frame = NSRect(origin: .zero, size: bubbleSize)
            hosting.autoresizingMask = [.width, .height]
            hostingView = hosting
            window.contentView = hosting
            applyAppearance()
        }

        installMouseHandlers()
        if viewModel.showWelcomeSetup || viewModel.showFeatureTour {
            transitionWindow(to: .quick)
        }
        window.orderFrontRegardless()
    }

    func applicationShouldHandleReopen(_ sender: NSApplication, hasVisibleWindows flag: Bool) -> Bool {
        window.makeKeyAndOrderFront(nil)
        window.orderFrontRegardless()
        return true
    }

    func applicationDidBecomeActive(_ notification: Notification) {
        applyAppearance()
    }

    func applicationDidResignActive(_ notification: Notification) {
        reassertAppearanceAfterFocusChange()
    }

    func windowDidBecomeKey(_ notification: Notification) {
        applyAppearance()
    }

    func windowDidResignKey(_ notification: Notification) {
        reassertAppearanceAfterFocusChange()
    }

    private func reassertAppearanceAfterFocusChange() {
        applyAppearance()
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.03) { [weak self] in
            self?.applyAppearance()
        }
    }

    func applyAppearance() {
        let name: NSAppearance.Name = viewModel.appearanceLightness < 0.5 ? .aqua : .darkAqua
        guard let appearance = NSAppearance(named: name) else { return }
        NSApp.appearance = appearance
        window?.appearance = appearance
        window?.contentView?.appearance = appearance
        hostingView?.lockAppearance(appearance)
    }

    func hideWindowCompletely() {
        window.orderOut(nil)
    }

    func setReduceMotion(_ enabled: Bool) {
        reduceMotionEnabled = enabled
    }

    func transitionWindow(to mode: GravityViewModel.UIMode) {
        guard WindowTransitionPolicy.canBegin(
            isTransitioning: viewModel.isWindowTransitioning,
            toBubble: mode == .bubble
        ) else { return }
        transitionGeneration = UUID()
        let generation = transitionGeneration
        let targetSize: CGSize
        switch mode {
        case .bubble: targetSize = bubbleSize
        case .quick: targetSize = viewModel.showWelcomeSetup ? setupSize : quickSize
        case .webResearch: targetSize = quickSize
        case .matrix: targetSize = matrixSize
        }
        let currentFrame = window.frame
        let topRight = CGPoint(x: currentFrame.maxX, y: currentFrame.maxY)

        var newFrame = NSRect(
            x: topRight.x - targetSize.width,
            y: topRight.y - targetSize.height,
            width: targetSize.width,
            height: targetSize.height
        )

        if mode != .bubble, let screen = (window.screen ?? NSScreen.main)?.visibleFrame {
            if newFrame.origin.x < screen.minX + 10 { newFrame.origin.x = screen.minX + 10 }
            if newFrame.origin.y < screen.minY + 10 { newFrame.origin.y = screen.minY + 10 }
            if newFrame.maxX > screen.maxX - 10 { newFrame.origin.x = screen.maxX - targetSize.width - 10 }
            if newFrame.maxY > screen.maxY - 10 { newFrame.origin.y = screen.maxY - targetSize.height - 10 }
        }

        let previousMode = viewModel.uiMode
        let transitionStyle = WindowTransitionPolicy.style(
            fromBubble: previousMode == .bubble,
            toBubble: mode == .bubble,
            reduceMotion: reduceMotionEnabled
        )

        // Make the nonactivating panel key before starting the SwiftUI morph.
        // Activating afterward can invalidate the first rendered frames.
        if mode != .bubble {
            window.makeKeyAndOrderFront(nil)
            NSApp.activate(ignoringOtherApps: true)
        }

        if transitionStyle == .immediate {
            if WindowTransitionPolicy.resizesFrameBeforeAnimation(for: transitionStyle) {
                window.setFrame(newFrame, display: false, animate: false)
            }
            viewModel.uiMode = mode
            viewModel.isWindowTransitioning = false
        } else if transitionStyle == .opening {
            viewModel.isWindowTransitioning = true
            // Resize without synchronously laying out and drawing the entire
            // expanded panel. Let AppKit publish the new host bounds for one
            // display refresh before SwiftUI starts animating its glass shape;
            // starting both in the same pass produced a visible first-frame hitch.
            window.setFrame(newFrame, display: false, animate: false)
            DispatchQueue.main.asyncAfter(
                deadline: .now() + WindowTransitionPolicy.openingLayoutSettleDelay
            ) { [weak self] in
                guard let self, self.transitionGeneration == generation else { return }
                withAnimation(
                    .spring(duration: WindowTransitionPolicy.openingDuration,
                            bounce: WindowTransitionPolicy.openingBounce),
                    completionCriteria: .removed
                ) {
                    self.viewModel.uiMode = mode
                } completion: { [weak self] in
                    guard let self, self.transitionGeneration == generation else { return }
                    self.viewModel.isWindowTransitioning = false
                }
            }
            scheduleTransitionWatchdog(generation: generation, mode: mode, frame: newFrame, style: transitionStyle)
        } else if transitionStyle == .closing {
            viewModel.isWindowTransitioning = true
            withAnimation(
                .spring(duration: WindowTransitionPolicy.closingDuration,
                        bounce: WindowTransitionPolicy.closingBounce),
                completionCriteria: .removed
            ) {
                viewModel.uiMode = mode
            } completion: { [weak self] in
                guard let self, self.transitionGeneration == generation,
                      self.viewModel.uiMode == .bubble else { return }
                // Resize after the spring with display disabled. Let AppKit
                // schedule the small host's next frame naturally; forcing a
                // synchronous layout here caused a visible end-of-close hitch.
                self.window.setFrame(newFrame, display: false, animate: false)
                self.viewModel.isWindowTransitioning = false
            }
            scheduleTransitionWatchdog(generation: generation, mode: mode, frame: newFrame, style: transitionStyle)
        } else {
            // Expanded-to-expanded navigation still resizes, with a restrained
            // curve; the bubble open/close path above never animates the window.
            viewModel.isWindowTransitioning = true
            withAnimation(.smooth(duration: 0.24)) {
                viewModel.uiMode = mode
            }
            NSAnimationContext.runAnimationGroup { context in
                context.duration = 0.24
                context.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
                context.completionHandler = { [weak self] in
                    guard let self, self.transitionGeneration == generation else { return }
                    self.viewModel.isWindowTransitioning = false
                }
                window.animator().setFrame(newFrame, display: true)
            }
            scheduleTransitionWatchdog(generation: generation, mode: mode, frame: newFrame, style: transitionStyle)
        }
    }

    private func scheduleTransitionWatchdog(
        generation: UUID,
        mode: GravityViewModel.UIMode,
        frame: NSRect,
        style: WindowTransitionStyle
    ) {
        let delay = WindowTransitionPolicy.watchdogDelay(for: style)
        guard delay > 0 else { return }
        DispatchQueue.main.asyncAfter(deadline: .now() + delay) { [weak self] in
            guard let self,
                  self.transitionGeneration == generation,
                  self.viewModel.uiMode == mode,
                  self.viewModel.isWindowTransitioning else { return }
            if mode == .bubble {
                self.window.setFrame(frame, display: false, animate: false)
            }
            self.viewModel.isWindowTransitioning = false
        }
    }

    private func installMouseHandlers() {
        if let rightMon = NSEvent.addLocalMonitorForEvents(matching: [.rightMouseDown], handler: { [weak self] event in
            guard let self = self, event.window == self.window else { return event }
            if self.viewModel.uiMode == .bubble {
                self.popUpBubbleContextMenu(with: event)
                return nil
            }
            return event
        }) {
            mouseMonitors.append(rightMon)
        }

        if let downMon = NSEvent.addLocalMonitorForEvents(matching: [.leftMouseDown], handler: { [weak self] event in
            guard let self = self, event.window == self.window else { return event }
            if event.modifierFlags.contains(.control) && self.viewModel.uiMode == .bubble {
                self.popUpBubbleContextMenu(with: event)
                return nil
            }
            guard !self.viewModel.isWindowTransitioning else { return event }
            let mouseLocation = NSEvent.mouseLocation
            let frameOrigin = self.window.frame.origin
            self.dragAnchorOffset = NSPoint(
                x: mouseLocation.x - frameOrigin.x,
                y: mouseLocation.y - frameOrigin.y
            )
            let point = event.locationInWindow
            let isBubble = self.viewModel.uiMode == .bubble
            let isHeader = !self.viewModel.showFeatureTour && point.y >= self.window.frame.height - 54
            self.pointerGesture.begin(at: mouseLocation, canDrag: isBubble || isHeader)
            return event
        }) {
            mouseMonitors.append(downMon)
        }

        if let dragMon = NSEvent.addLocalMonitorForEvents(matching: [.leftMouseDragged], handler: { [weak self] event in
            guard let self = self, event.window == self.window else { return event }
            let current = NSEvent.mouseLocation
            guard self.pointerGesture.update(to: current) else { return event }
            // Anchor the window to the original mouse-down offset. Computing
            // every frame from this fixed offset avoids cumulative drift and
            // keeps the grabbed point directly under the cursor.
            self.window.setFrameOrigin(NSPoint(
                x: current.x - self.dragAnchorOffset.x,
                y: current.y - self.dragAnchorOffset.y
            ))
            return nil
        }) {
            mouseMonitors.append(dragMon)
        }

        if let upMon = NSEvent.addLocalMonitorForEvents(matching: [.leftMouseUp], handler: { [weak self] event in
            guard let self = self, event.window == self.window else { return event }
            guard !self.viewModel.isWindowTransitioning else { return event }
            // Footer buttons and ordinary clicks always reach SwiftUI.
            if self.pointerGesture.end() { return nil }
            if self.viewModel.uiMode == .bubble {
                // The orb is one target. A hidden corner hot zone made a
                // normal click open old history instead of a fresh chat.
                self.viewModel.openFreshQuickChat()
                return nil
            }
            return event
        }) {
            mouseMonitors.append(upMon)
        }
    }

    private func popUpBubbleContextMenu(with event: NSEvent) {
        let menu = NSMenu(title: "Assistente Gravity")

        let quickItem = NSMenuItem(title: "Novo Chat Rápido", action: #selector(menuOpenQuick), keyEquivalent: "")
        quickItem.target = self
        menu.addItem(quickItem)

        let matrixItem = NSMenuItem(title: "Abrir Histórico (Matriz)", action: #selector(menuOpenMatrix), keyEquivalent: "")
        matrixItem.target = self
        menu.addItem(matrixItem)

        menu.addItem(NSMenuItem.separator())

        let hideItem = NSMenuItem(title: "Ocultar Ícone", action: #selector(menuHideOrb), keyEquivalent: "")
        hideItem.target = self
        menu.addItem(hideItem)

        let folderItem = NSMenuItem(title: "Abrir Pasta 1_IA's", action: #selector(menuOpenFolder), keyEquivalent: "")
        folderItem.target = self
        menu.addItem(folderItem)

        menu.addItem(NSMenuItem.separator())

        let quitItem = NSMenuItem(title: "Encerrar", action: #selector(menuQuit), keyEquivalent: "")
        quitItem.target = self
        menu.addItem(quitItem)

        if let contentView = window.contentView {
            NSMenu.popUpContextMenu(menu, with: event, for: contentView)
        }
    }

    @objc private func menuOpenQuick() {
        viewModel.openFreshQuickChat()
    }

    @objc private func menuOpenMatrix() {
        viewModel.openMatrixHub()
    }

    @objc private func menuHideOrb() {
        hideWindowCompletely()
    }

    @objc private func menuOpenFolder() {
        viewModel.openFile(GravityPaths.work + "/ANTIGRAVITY")
    }

    @objc private func menuQuit() {
        NSApp.terminate(nil)
    }
}
