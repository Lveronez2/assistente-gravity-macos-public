import AppKit
import Foundation
import PDFKit
import UniformTypeIdentifiers
import Vision

enum SearchReferenceKind: String, Sendable {
    case image
    case document
}

struct SearchReferenceInfo: Equatable, Sendable {
    let id: UUID
    let url: URL
    let name: String
    let kind: SearchReferenceKind
}

struct PreparedSearchReference: @unchecked Sendable {
    let info: SearchReferenceInfo
    let stagedURL: URL
    let stagedDirectory: URL
    let extractedText: String
    private let lease: SearchReferenceStagingLease

    init(info: SearchReferenceInfo, stagedURL: URL, stagedDirectory: URL, extractedText: String) {
        self.info = info
        self.stagedURL = stagedURL
        self.stagedDirectory = stagedDirectory
        self.extractedText = extractedText
        self.lease = SearchReferenceStagingLease(directory: stagedDirectory)
    }

    func cleanup() { lease.cleanup() }
}

private final class SearchReferenceStagingLease: @unchecked Sendable {
    private let lock = NSLock()
    private let directory: URL
    private var isCleaned = false

    init(directory: URL) { self.directory = directory }

    func cleanup() {
        lock.lock()
        guard !isCleaned else { lock.unlock(); return }
        isCleaned = true
        lock.unlock()
        try? FileManager.default.removeItem(at: directory)
    }

    deinit { cleanup() }
}

enum SearchReferenceService {
    static let maximumFileSize = 30 * 1024 * 1024
    private static let supportedExtensions: Set<String> = [
        "png", "jpg", "jpeg", "tif", "tiff", "gif", "bmp", "heic", "webp",
        "pdf", "txt", "md", "rtf", "doc", "docx", "docm", "odt", "pages",
        "csv", "xls", "xlsx", "ppt", "pptx", "html", "htm"
    ]
    private static let imageExtensions: Set<String> = ["png", "jpg", "jpeg", "tif", "tiff", "gif", "bmp", "heic", "webp"]

    static var allowedContentTypes: [UTType] {
        let extensions = supportedExtensions.compactMap { UTType(filenameExtension: $0) }
        return Array(Set([.image, .pdf, .plainText, .rtf] + extensions))
    }

    static func makeInfo(for url: URL) throws -> SearchReferenceInfo {
        let fileURL = url.standardizedFileURL
        let ext = fileURL.pathExtension.lowercased()
        guard supportedExtensions.contains(ext) else { throw SearchReferenceError.unsupportedType }
        guard let values = try? fileURL.resourceValues(forKeys: [.isRegularFileKey, .fileSizeKey]),
              values.isRegularFile == true else { throw SearchReferenceError.notAFile }
        guard (values.fileSize ?? 0) <= maximumFileSize else { throw SearchReferenceError.fileTooLarge }
        return SearchReferenceInfo(
            id: UUID(),
            url: fileURL,
            name: fileURL.lastPathComponent,
            kind: imageExtensions.contains(ext) ? .image : .document
        )
    }

    static func prepare(_ info: SearchReferenceInfo) throws -> PreparedSearchReference {
        let source = info.url
        let hasSecurityScope = source.startAccessingSecurityScopedResource()
        defer { if hasSecurityScope { source.stopAccessingSecurityScopedResource() } }

        let ext = source.pathExtension.lowercased()
        let directory = FileManager.default.temporaryDirectory
            .appendingPathComponent("AssistenteGravity-SearchReference-\(info.id.uuidString)", isDirectory: true)
        do {
            try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
            let stagedURL = directory.appendingPathComponent("referencia.\(ext)")
            try FileManager.default.copyItem(at: source, to: stagedURL)
            let text = extractText(from: source, extension: ext)
            return PreparedSearchReference(
                info: info,
                stagedURL: stagedURL,
                stagedDirectory: directory,
                extractedText: String(text.prefix(12_000)).trimmingCharacters(in: .whitespacesAndNewlines)
            )
        } catch {
            try? FileManager.default.removeItem(at: directory)
            throw SearchReferenceError.couldNotRead(error.localizedDescription)
        }
    }

    private static func extractText(from url: URL, extension ext: String) -> String {
        if ext == "pdf" { return PDFDocument(url: url)?.string ?? "" }
        if imageExtensions.contains(ext) { return recognizeText(in: url) }
        if ["txt", "md", "csv", "html", "htm"].contains(ext),
           let text = try? String(contentsOf: url, encoding: .utf8) { return text }
        return (try? NSAttributedString(url: url, options: [:], documentAttributes: nil).string) ?? ""
    }

    private static func recognizeText(in url: URL) -> String {
        let request = VNRecognizeTextRequest()
        request.recognitionLevel = .accurate
        request.usesLanguageCorrection = true
        do {
            try VNImageRequestHandler(url: url).perform([request])
            return request.results?.compactMap { $0.topCandidates(1).first?.string }.joined(separator: "\n") ?? ""
        } catch {
            return ""
        }
    }
}

enum SearchReferenceError: LocalizedError {
    case unsupportedType
    case notAFile
    case fileTooLarge
    case couldNotRead(String)

    var errorDescription: String? {
        switch self {
        case .unsupportedType: "Escolha uma imagem ou um documento compatível."
        case .notAFile: "O item escolhido não é um arquivo."
        case .fileTooLarge: "A referência precisa ter até 30 MB."
        case .couldNotRead(let detail): "Não consegui preparar essa referência: \(detail)"
        }
    }
}
