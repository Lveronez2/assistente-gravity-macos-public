import Foundation

struct QuickSearchHistory: Codable {
    struct Entry: Codable, Equatable {
        var query: String
        var count: Int
        var lastUsed: Date

        var identity: String {
            query.folding(options: [.caseInsensitive, .diacriticInsensitive], locale: .current)
                .split(whereSeparator: \.isWhitespace)
                .joined(separator: " ")
        }
    }

    private(set) var entries: [Entry] = []
    private static let maximumEntries = 30

    mutating func record(_ rawQuery: String, at date: Date = Date()) {
        let query = rawQuery.split(whereSeparator: \.isWhitespace).joined(separator: " ")
        guard !query.isEmpty else { return }

        let identity = query.folding(options: [.caseInsensitive, .diacriticInsensitive], locale: .current)
        if let index = entries.firstIndex(where: { $0.identity == identity }) {
            entries[index].query = query
            entries[index].count += 1
            entries[index].lastUsed = date
        } else {
            entries.append(Entry(query: query, count: 1, lastUsed: date))
        }

        entries.sort { $0.lastUsed > $1.lastUsed }
        if entries.count > Self.maximumEntries {
            entries.removeLast(entries.count - Self.maximumEntries)
        }
    }

    /// Put the latest search first, then fill the row with the most frequent
    /// searches, using recency to break ties.
    func suggestions(limit: Int = 5) -> [String] {
        guard limit > 0, let latest = entries.max(by: { $0.lastUsed < $1.lastUsed }) else { return [] }
        var result = [latest.query]
        for entry in entries.sorted(by: {
            if $0.count != $1.count { return $0.count > $1.count }
            return $0.lastUsed > $1.lastUsed
        }) where !result.contains(where: {
            $0.folding(options: [.caseInsensitive, .diacriticInsensitive], locale: .current)
                == entry.identity
        }) {
            result.append(entry.query)
            if result.count == limit { break }
        }
        return Array(result.prefix(limit))
    }
}
