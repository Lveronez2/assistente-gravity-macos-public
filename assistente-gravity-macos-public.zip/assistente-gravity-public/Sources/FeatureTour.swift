import SwiftUI

enum TourFeature: Int, CaseIterable, Identifiable {
    case search, reference, research, history, settings, minimize
    var id: Int { rawValue }
    var symbol: String {
        switch self {
        case .search: "magnifyingglass"
        case .reference: "paperclip"
        case .research: "sparkles"
        case .history: "clock"
        case .settings: "slider.horizontal.3"
        case .minimize: "minus"
        }
    }
    var title: String {
        switch self {
        case .search: "Encontre sem procurar em pastas"
        case .reference: "Busque com uma referência"
        case .research: "Uma pergunta, uma conversa"
        case .history: "Retome de onde parou"
        case .settings: "Deixe o Gravity do seu jeito"
        case .minimize: "Sempre por perto"
        }
    }
    var detail: String {
        switch self {
        case .search: "Escreva algo como “logo atualizada da marca”. O Gravity busca nas pastas que você autorizou e mostra os arquivos para abrir ou arrastar."
        case .reference: "Use o clipe ou solte imagem/documento. A imagem orienta a comparação visual; o documento pode trazer critérios para buscas complexas. O anexo será analisado pela conta Antigravity conectada."
        case .research: "Use Perguntar à IA para tirar dúvidas e pesquisar na internet. As respostas podem incluir fontes para você conferir."
        case .history: "Suas buscas de arquivos e conversas com a IA ficam separadas. Selecione uma conversa para continuar ou exclua quando quiser."
        case .settings: "Escolha as pastas de busca, troque a conta Google e ajuste a aparência e a intensidade do vidro."
        case .minimize: "Recolha o painel sem encerrar o app. Clique no anel para voltar e arraste o ícone ou o topo do painel para movê-lo."
        }
    }
}

struct TourAnchorKey: PreferenceKey {
    static var defaultValue: [TourFeature: Anchor<CGRect>] { [:] }
    static func reduce(value: inout [TourFeature: Anchor<CGRect>], nextValue: () -> [TourFeature: Anchor<CGRect>]) {
        value.merge(nextValue(), uniquingKeysWith: { _, next in next })
    }
}

extension View {
    func tourTarget(_ feature: TourFeature) -> some View {
        anchorPreference(key: TourAnchorKey.self, value: .bounds) { [feature: $0] }
    }
}

final class FeatureTourState: ObservableObject {
    @Published var step = 0
    @Published var cursor = CGPoint(x: 40, y: 180)
    @Published var clicked = false
}

@available(macOS 26.0, *)
struct FeatureTourOverlay: View {
    let anchors: [TourFeature: Anchor<CGRect>]
    let finish: () -> Void
    @ObservedObject var presentation: FeatureTourState
    @FocusState private var nextFocused: Bool
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    private var feature: TourFeature { TourFeature.allCases[presentation.step] }

    var body: some View {
        GeometryReader { proxy in
            let bounds: CGRect = {
                if let featureAnchor = anchors[feature] {
                    return proxy[featureAnchor].insetBy(dx: -5, dy: -5)
                }
                if feature == .reference, let searchAnchor = anchors[.search] {
                    let searchBounds = proxy[searchAnchor]
                    return CGRect(
                        x: searchBounds.maxX - 39,
                        y: searchBounds.midY - 16,
                        width: 32,
                        height: 32
                    ).insetBy(dx: -5, dy: -5)
                }
                return CGRect(x: 24, y: 70, width: proxy.size.width - 48, height: 40)
            }()
            let below = bounds.midY < proxy.size.height * 0.55
            let width = min(350.0, proxy.size.width - 40)
            let x = min(max(bounds.midX, width / 2 + 20), proxy.size.width - width / 2 - 20)
            let y = below ? min(bounds.maxY + 132, proxy.size.height - 128) : max(bounds.minY - 132, 128)

            ZStack(alignment: .topLeading) {
                // The cutout reveals the actual control, not a screenshot copy.
                Path { path in
                    path.addRect(CGRect(origin: .zero, size: proxy.size))
                    path.addRoundedRect(in: bounds, cornerSize: CGSize(width: 13, height: 13))
                }
                .fill(.black.opacity(0.64), style: FillStyle(eoFill: true))
                .onTapGesture { } // prevent clicks from reaching the app underneath
                .accessibilityHidden(true)

                RoundedRectangle(cornerRadius: 13)
                    .strokeBorder(.white.opacity(0.9), lineWidth: 1.5)
                    .frame(width: bounds.width, height: bounds.height)
                    .position(x: bounds.midX, y: bounds.midY)
                    .shadow(color: .cyan.opacity(0.35), radius: 8)
                    .allowsHitTesting(false)

                // Clicking the highlighted control advances the demonstration.
                Button { advance() } label: { Color.clear.contentShape(Rectangle()) }
                    .buttonStyle(.plain)
                    .frame(width: bounds.width, height: bounds.height)
                    .position(x: bounds.midX, y: bounds.midY)
                    .accessibilityLabel("Conhecer próxima função")

                Circle()
                    .stroke(.white.opacity(presentation.clicked ? 0 : 0.9), lineWidth: 2)
                    .frame(width: presentation.clicked ? 44 : 10, height: presentation.clicked ? 44 : 10)
                    .position(presentation.cursor)
                    .allowsHitTesting(false)
                    .accessibilityHidden(true)

                Image(systemName: "cursorarrow")
                    .font(.system(size: 28, weight: .black))
                    .foregroundStyle(.white)
                    .shadow(color: .black.opacity(0.8), radius: 2, y: 1)
                    .scaleEffect(presentation.clicked ? 0.88 : 1, anchor: .topLeading)
                    .position(x: presentation.cursor.x + 8, y: presentation.cursor.y + 14)
                    .allowsHitTesting(false)
                    .accessibilityHidden(true)

                balloon
                    .frame(width: width)
                    .position(x: x, y: y)
            }
            .task(id: presentation.step) {
                presentation.clicked = false
                nextFocused = true
                let destination = CGPoint(x: bounds.midX, y: bounds.midY)
                if reduceMotion {
                    presentation.cursor = destination
                    return
                }
                withAnimation(.easeInOut(duration: 0.7)) { presentation.cursor = destination }
                do { try await Task.sleep(for: .milliseconds(780)) } catch { return }
                guard !Task.isCancelled else { return }
                withAnimation(.easeOut(duration: 0.45)) { presentation.clicked = true }
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
        .onKeyPress(.escape) { finish(); return .handled }
        .accessibilityElement(children: .contain)
        .accessibilityLabel("Tour do Gravity, passo \(presentation.step + 1) de \(TourFeature.allCases.count)")
    }

    private var balloon: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Label("CONHEÇA O GRAVITY", systemImage: feature.symbol)
                    .font(.system(size: 10, weight: .semibold))
                    .foregroundStyle(.secondary)
                Spacer()
                Text("\(presentation.step + 1) de \(TourFeature.allCases.count)")
                    .font(.system(size: 10).monospacedDigit())
                    .foregroundStyle(.secondary)
            }
            Text(feature.title)
                .font(.system(size: 19, weight: .semibold))
                .fixedSize(horizontal: false, vertical: true)
            Text(feature.detail)
                .font(.system(size: 12))
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
            HStack(spacing: 5) {
                ForEach(TourFeature.allCases) { item in
                    Capsule().fill(item.rawValue == presentation.step ? Color.cyan : Color.secondary.opacity(0.25))
                        .frame(width: item.rawValue == presentation.step ? 20 : 5, height: 4)
                }
                Spacer()
                Button("Pular") { finish() }.buttonStyle(.plain)
                    .font(.system(size: 11))
                    .foregroundStyle(.secondary)
            }
            HStack {
                if presentation.step > 0 {
                    Button("Voltar") { presentation.step -= 1 }
                        .buttonStyle(.borderless)
                }
                Spacer()
                Button(presentation.step == TourFeature.allCases.count - 1 ? "Começar a usar" : "Próximo") { advance() }
                    .buttonStyle(.glassProminent)
                    .focused($nextFocused)
                    .keyboardShortcut(.defaultAction)
                    .accessibilityIdentifier("gravity-tour-next")
            }
            Text("Demonstração · nenhuma pesquisa é enviada")
                .font(.system(size: 9))
                .foregroundStyle(.secondary)
        }
        .padding(20)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 18))
        .overlay { RoundedRectangle(cornerRadius: 18).strokeBorder(.white.opacity(0.3), lineWidth: 0.75) }
        .shadow(color: .black.opacity(0.35), radius: 18, y: 8)
        .foregroundStyle(.primary)
    }

    private func advance() {
        if presentation.step < TourFeature.allCases.count - 1 { presentation.step += 1 }
        else { finish() }
    }
}
