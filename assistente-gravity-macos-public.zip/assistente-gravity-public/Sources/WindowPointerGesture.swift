import Foundation
import CoreGraphics

/// Mouse-up is consumed only after an actual drag in a draggable region.
struct WindowPointerGesture {
    private var origin = CGPoint.zero
    private var canDrag = false
    private var dragged = false

    mutating func begin(at point: CGPoint, canDrag: Bool) {
        origin = point
        self.canDrag = canDrag
        dragged = false
    }

    mutating func update(to point: CGPoint) -> Bool {
        guard canDrag else { return false }
        if hypot(point.x - origin.x, point.y - origin.y) > 5 { dragged = true }
        return dragged
    }

    mutating func end() -> Bool {
        let consumed = dragged
        canDrag = false
        dragged = false
        return consumed
    }
}
