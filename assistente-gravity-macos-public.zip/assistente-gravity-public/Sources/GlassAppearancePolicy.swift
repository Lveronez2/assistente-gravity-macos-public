import Foundation

enum GlassAppearancePolicy {
    static let maximumIntensity = 2.0
    static let maximumTransparency = 1.0

    static func clampedIntensity(_ value: Double) -> Double {
        min(maximumIntensity, max(0, value))
    }

    static func clampedTransparency(_ value: Double) -> Double {
        min(maximumTransparency, max(0, value))
    }

    static func surfaceBrightness(isLight: Bool) -> Double {
        isLight ? 1.0 : 0.34
    }

    static func surfaceOpacity(intensity: Double, transparency: Double) -> Double {
        let strength = clampedIntensity(intensity)
        let translucency = clampedTransparency(transparency)
        return min(1, max(0.08, 0.90 - strength * 0.13 - translucency * 0.68))
    }

    static func edgeOpticalStrength(intensity: Double) -> Double {
        0.45 + (clampedIntensity(intensity) / maximumIntensity) * 0.55
    }

    static func focusStabilizerOpacity(intensity: Double, transparency: Double, appearsActive: Bool) -> Double {
        guard !appearsActive else { return 0 }
        let strength = clampedIntensity(intensity) / maximumIntensity
        return clampedTransparency(transparency) * (0.55 + strength * 0.15)
    }
}
