import Foundation

struct WebSearchSource: Identifiable, Codable, Equatable, Sendable {
    var id: String { url }
    let title: String
    let url: String
    let snippet: String
    let domain: String
}

enum WebResearchEngine {
    private struct SearchAnchor {
        let href: String
        let text: String
    }

    static func search(query: String) async throws -> [WebSearchSource] {
        guard var components = URLComponents(string: "https://html.duckduckgo.com/html/") else {
            throw SearchError.invalidAddress
        }
        components.queryItems = [URLQueryItem(name: "q", value: query)]
        guard let url = components.url else { throw SearchError.invalidAddress }

        var request = URLRequest(url: url, timeoutInterval: 20)
        request.setValue("text/html,application/xhtml+xml", forHTTPHeaderField: "Accept")
        request.setValue("Mozilla/5.0 (Macintosh; Intel Mac OS X) AppleWebKit/605.1.15 Safari/605.1.15", forHTTPHeaderField: "User-Agent")

        let (data, response) = try await URLSession.shared.data(for: request)
        guard let response = response as? HTTPURLResponse, (200..<300).contains(response.statusCode) else {
            throw SearchError.unavailable
        }
        guard let html = String(data: data, encoding: .utf8) else { throw SearchError.invalidResponse }

        let links = anchors(in: html, matchingClass: "result__a")
        let snippets = anchors(in: html, matchingClass: "result__snippet")
        var seen = Set<String>()

        return links.enumerated().compactMap { index, link in
            guard let target = destination(from: link.href),
                  let host = URLComponents(string: target)?.host,
                  !host.localizedCaseInsensitiveContains("duckduckgo.com"),
                  seen.insert(target).inserted else { return nil }
            let snippet = index < snippets.count ? snippets[index].text : ""
            return WebSearchSource(
                title: link.text.isEmpty ? host : link.text,
                url: target,
                snippet: snippet,
                domain: host.replacingOccurrences(of: "www.", with: "")
            )
        }
        .prefix(6)
        .map { $0 }
    }

    private static func anchors(in html: String, matchingClass className: String) -> [SearchAnchor] {
        let pattern = #"<a\b([^>]*)>(.*?)</a>"#
        guard let expression = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive, .dotMatchesLineSeparators]) else { return [] }
        let source = html as NSString
        return expression.matches(in: html, range: NSRange(location: 0, length: source.length)).compactMap { match in
            let attributes = source.substring(with: match.range(at: 1))
            let classes = attribute("class", from: attributes).split(whereSeparator: \.isWhitespace)
            guard classes.contains(where: { $0 == Substring(className) }),
                  let href = attribute("href", from: attributes).nilIfEmpty else { return nil }
            let rawText = source.substring(with: match.range(at: 2))
            return SearchAnchor(href: decodeEntities(href), text: decodeEntities(stripTags(rawText)))
        }
    }

    private static func attribute(_ name: String, from attributes: String) -> String {
        let pattern = #"\b\#(NSRegularExpression.escapedPattern(for: name))\s*=\s*[\"']([^\"']*)[\"']"#
        guard let expression = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive]),
              let match = expression.firstMatch(in: attributes, range: NSRange(attributes.startIndex..., in: attributes)),
              let range = Range(match.range(at: 1), in: attributes) else { return "" }
        return String(attributes[range])
    }

    private static func destination(from href: String) -> String? {
        guard let url = URL(string: href, relativeTo: URL(string: "https://html.duckduckgo.com"))?.absoluteURL,
              let components = URLComponents(url: url, resolvingAgainstBaseURL: false) else { return nil }
        if components.host?.localizedCaseInsensitiveContains("duckduckgo.com") == true,
           let target = components.queryItems?.first(where: { $0.name == "uddg" })?.value {
            return safeWebURL(target)
        }
        return safeWebURL(url.absoluteString)
    }

    private static func safeWebURL(_ value: String) -> String? {
        guard let components = URLComponents(string: value),
              let scheme = components.scheme?.lowercased(),
              ["http", "https"].contains(scheme),
              components.host != nil else { return nil }
        return components.url?.absoluteString
    }

    private static func stripTags(_ value: String) -> String {
        guard let expression = try? NSRegularExpression(pattern: #"<[^>]+>"#) else { return value }
        let range = NSRange(value.startIndex..., in: value)
        return expression.stringByReplacingMatches(in: value, range: range, withTemplate: " ")
    }

    private static func decodeEntities(_ value: String) -> String {
        var decoded = value
        for (entity, character) in [
            ("&amp;", "&"), ("&quot;", "\""), ("&#39;", "'"), ("&apos;", "'"),
            ("&lt;", "<"), ("&gt;", ">"), ("&nbsp;", " ")
        ] {
            decoded = decoded.replacingOccurrences(of: entity, with: character, options: .caseInsensitive)
        }
        return decoded.replacingOccurrences(of: #"\s+"#, with: " ", options: .regularExpression)
            .trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private enum SearchError: LocalizedError {
        case invalidAddress
        case unavailable
        case invalidResponse

        var errorDescription: String? {
            switch self {
            case .invalidAddress: "A pesquisa não pôde ser preparada."
            case .unavailable: "O serviço de pesquisa está indisponível no momento."
            case .invalidResponse: "O serviço de pesquisa retornou uma resposta inválida."
            }
        }
    }
}

private extension String {
    var nilIfEmpty: String? { isEmpty ? nil : self }
}

