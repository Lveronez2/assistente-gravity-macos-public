import Foundation
import CoreGraphics

enum WindowTransitionStyle: Equatable {
    case immediate
    case opening
    case closing
    case resizing
}

/// Keeps the bubble/panel transition timing and frame-resize order in one
/// testable place so later animation edits cannot reintroduce the old jump.
enum WindowTransitionPolicy {
    static let openingDuration = 0.40
    static let openingBounce = 0.12
    // Give AppKit one refresh to publish the enlarged host bounds before
    // SwiftUI animates the shared glass surface inside it.
    static let openingLayoutSettleDelay = 1.0 / 60.0
    static let closingDuration = 0.40
    static let closingBounce = 0.16
    static let panelContentFadeDuration = 0.24
    static let orbFadeDuration = 0.14
    static let transitionWatchdogGracePeriod = 0.35

    static func watchdogDelay(for style: WindowTransitionStyle) -> TimeInterval {
        switch style {
        case .opening: openingDuration + transitionWatchdogGracePeriod
        case .closing: closingDuration + transitionWatchdogGracePeriod
        case .resizing: 0.24 + transitionWatchdogGracePeriod
        case .immediate: 0
        }
    }

    static func surfaceSize(expanded: Bool, available: CGSize) -> CGSize {
        expanded ? available : CGSize(width: 64, height: 64)
    }

    static func surfaceCornerRadius(expanded: Bool) -> CGFloat {
        expanded ? 20 : 32
    }

    static func canBegin(isTransitioning: Bool, toBubble: Bool = false) -> Bool {
        !isTransitioning || toBubble
    }

    static func style(fromBubble: Bool, toBubble: Bool, reduceMotion: Bool) -> WindowTransitionStyle {
        if reduceMotion { return .immediate }
        if fromBubble && !toBubble { return .opening }
        if !fromBubble && toBubble { return .closing }
        return .resizing
    }

    static func resizesFrameBeforeAnimation(for style: WindowTransitionStyle) -> Bool {
        style == .immediate || style == .opening
    }

    static func resizesFrameAfterAnimation(for style: WindowTransitionStyle) -> Bool {
        style == .closing
    }

}
