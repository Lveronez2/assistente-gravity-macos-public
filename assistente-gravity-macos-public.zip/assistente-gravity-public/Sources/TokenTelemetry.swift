import Foundation

struct AntigravityQuotaBucket: Equatable, Identifiable, Sendable {
    let id: String
    let group: String
    let name: String
    let window: String
    let remainingFraction: Double
    let resetAt: String?
}

struct TokenTelemetry: Equatable {
    var modelID = ""
    var modelName = "Antigravity"
    var quotaBuckets: [AntigravityQuotaBucket] = []
    var latestRequestTokens: Int?
    var activeRequestTokens: Int?
    var sessionTokens = 0
    var isRefreshingQuota = true
    var quotaError: String?
    var updatedAt = "--:--"

    var applicableBuckets: [AntigravityQuotaBucket] {
        let id = modelID.lowercased()
        let modelGroup: (String) -> Bool
        if id.contains("claude") || id.contains("gpt") {
            modelGroup = { $0.localizedCaseInsensitiveContains("claude") || $0.localizedCaseInsensitiveContains("gpt") }
        } else if id.contains("argon") {
            modelGroup = { $0.localizedCaseInsensitiveContains("gemini") }
        } else if id.contains("gemini") || id.contains("flash") || id.contains("hydrogen") || id.contains("carbon") {
            modelGroup = { $0.localizedCaseInsensitiveContains("gemini") }
        } else {
            modelGroup = { _ in true }
        }
        let matching = quotaBuckets.filter { modelGroup($0.group) }
        return matching.isEmpty ? quotaBuckets : matching
    }

    var limitingBucket: AntigravityQuotaBucket? {
        applicableBuckets.min { $0.remainingFraction < $1.remainingFraction }
    }

    var remainingFraction: Double? {
        limitingBucket?.remainingFraction
    }

    var quotaLabel: String {
        guard let bucket = limitingBucket else { return "Cota do Antigravity" }
        let window = bucket.window == "5h" ? "5 h" : (bucket.window == "weekly" ? "semanal" : bucket.window)
        return "\(bucket.group) · \(window)"
    }
}

enum AntigravityTelemetryClient {
    static func fetch(agy: String) async -> (modelID: String, modelName: String, buckets: [AntigravityQuotaBucket], error: String?) {
        async let modelCall = Task.detached(priority: .utility) { run(agy: agy, arguments: ["-p", "/model", "--output-format", "json", "--print-timeout", "25s"]) }.value
        async let usageCall = Task.detached(priority: .utility) { run(agy: agy, arguments: ["-p", "/usage", "--output-format", "json", "--print-timeout", "25s"]) }.value
        let (model, usage) = await (modelCall, usageCall)
        return parse(model: model, usage: usage)
    }

    static func run(agy: String, arguments: [String]) -> [String: Any]? {
        let process = Process()
        let output = Pipe()
        process.executableURL = URL(fileURLWithPath: agy)
        process.arguments = arguments
        process.standardOutput = output
        process.standardError = FileHandle.nullDevice
        do {
            try process.run()
            let data = output.fileHandleForReading.readDataToEndOfFile()
            process.waitUntilExit()
            guard process.terminationStatus == 0,
                  let envelope = try JSONSerialization.jsonObject(with: data) as? [String: Any] else { return nil }
            return envelope
        } catch { return nil }
    }

    static func parse(model: [String: Any]?, usage: [String: Any]?) -> (modelID: String, modelName: String, buckets: [AntigravityQuotaBucket], error: String?) {
        let modelDetails = ((model?["command"] as? [String: Any])?["data"] as? [String: Any])
        let modelID = modelDetails?["id"] as? String ?? ""
        let modelName = modelDetails?["label"] as? String ?? "Antigravity"
        let usageData = ((usage?["command"] as? [String: Any])?["data"] as? [String: Any])
        let groups = usageData?["groups"] as? [[String: Any]] ?? []
        let buckets = groups.flatMap { group -> [AntigravityQuotaBucket] in
            let groupName = group["name"] as? String ?? "Modelo"
            return (group["buckets"] as? [[String: Any]] ?? []).compactMap { bucket in
                guard let fraction = bucket["remaining_fraction"] as? Double else { return nil }
                return AntigravityQuotaBucket(
                    id: bucket["id"] as? String ?? UUID().uuidString,
                    group: groupName,
                    name: bucket["name"] as? String ?? "Cota",
                    window: bucket["window"] as? String ?? "",
                    remainingFraction: min(1, max(0, fraction)),
                    resetAt: bucket["reset_time"] as? String
                )
            }
        }
        return (modelID, modelName, buckets, buckets.isEmpty ? "Cota indisponível" : nil)
    }

}
