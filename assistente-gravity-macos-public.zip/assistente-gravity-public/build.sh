#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
output="${1:?Informe o diretório de saída}"
mode="${2:-preview}"
case "$mode" in
    preview) appName="Assistente Gravity Preview"; bundle="com.gravity.assistente.preview" ;;
    release) appName="Assistente Gravity"; bundle="com.gravity.assistente" ;;
    *) echo "Modo inválido. Use preview ou release." >&2; exit 2 ;;
esac
mkdir -p "$output"
output="$(cd "$output" && pwd)"
app="$output/$appName.app"
if [[ -e "$app" ]]; then
    echo "A saída já existe. Use um diretório novo." >&2
    exit 1
fi
stage="$(mktemp -d /tmp/gravity-build.XXXXXX)"
trap 'rm -rf "$stage"' EXIT
contents="$stage/$appName.app/Contents"
mkdir -p "$contents/MacOS" "$contents/Resources"
cp -X Resources/Info.plist "$contents/Info.plist"
cp -X Resources/AppIcon.icns Resources/prism_ring.png Resources/connect-antigravity.command "$contents/Resources/"
chmod +x "$contents/Resources/connect-antigravity.command"
plutil -replace CFBundleIdentifier -string "$bundle" "$contents/Info.plist"
plutil -replace CFBundleName -string "$appName" "$contents/Info.plist"
plutil -replace CFBundleDisplayName -string "$appName" "$contents/Info.plist"
xcrun swiftc -O -target arm64-apple-macos26.0 -module-cache-path "${GRAVITY_SWIFT_CACHE:-$stage/cache}" Sources/main.swift Sources/SmartFinderEngine.swift Sources/SearchIndex.swift Sources/SearchReference.swift Sources/TokenTelemetry.swift Sources/WindowCoordinator.swift Sources/WindowTransitionPolicy.swift Sources/GlassAppearancePolicy.swift Sources/QuickSearchHistory.swift Sources/WebResearchEngine.swift Sources/WindowPointerGesture.swift Sources/RefinementPolicy.swift Sources/FeatureTour.swift -o "$contents/MacOS/AssistenteGravity"
xattr -cr "$stage/$appName.app"
if [[ -n "${GRAVITY_CODESIGN_IDENTITY:-}" ]]; then
    codesign --force --sign "$GRAVITY_CODESIGN_IDENTITY" "$stage/$appName.app"
else
    echo "Aviso: assinatura ad hoc. O macOS pode pedir autorização de pastas novamente após recompilar o app." >&2
    echo "Para reutilizar a identidade de acesso entre versões, defina GRAVITY_CODESIGN_IDENTITY com uma identidade de assinatura instalada." >&2
    codesign --force --sign - "$stage/$appName.app"
fi
codesign --verify --deep --strict "$stage/$appName.app"
mv "$stage/$appName.app" "$app"
echo "$app"
