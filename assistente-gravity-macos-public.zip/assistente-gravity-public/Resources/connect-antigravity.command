#!/bin/zsh
set -e

AGY_BIN="$HOME/.local/bin/agy"

if [[ ! -x "$AGY_BIN" ]]; then
  clear
  echo "Assistente Gravity — configuração do Antigravity"
  echo
  echo "O CLI oficial do Antigravity será instalado a partir de antigravity.google."
  echo "Pressione Enter para continuar ou feche esta janela para cancelar."
  read -r
  /bin/zsh -c 'curl -fsSL https://antigravity.google/cli/install.sh | bash'
fi

if [[ ! -x "$AGY_BIN" ]]; then
  echo "Não encontrei o CLI em $AGY_BIN. Confira a instalação e tente novamente."
  read -r "?Pressione Enter para fechar."
  exit 1
fi

echo "Se esta for a primeira utilização, escolha Google OAuth e entre na sua conta no navegador."
echo "Ao concluir o login, feche o Antigravity CLI com Ctrl+D e volte ao Assistente Gravity."
echo
SETUP_DIR="$HOME/Library/Application Support/Assistente Gravity/Antigravity Workspace"
mkdir -p "$SETUP_DIR"
cd "$SETUP_DIR"
exec "$AGY_BIN"
