# Assistente Gravity para macOS

Código-fonte público do Assistente Gravity. Esta cópia começa com um histórico Git limpo e omite configurações internas de clientes, caminhos de servidores e dados de uso. O repositório de trabalho interno continua separado.

## Compatibilidade

- macOS 26 ou posterior
- Apple silicon (arm64)
- Xcode Command Line Tools e SDK do macOS 26+

O projeto usa Liquid Glass nativo e ainda não tem interface compatível com macOS Sonoma 14 ou Sequoia 15.

## Compilar

```sh
./build.sh ./build release
```

Isso compila o código-fonte e gera um app local, sem assinatura Developer ID nem notarização. A distribuição instalável e sem alertas do Gatekeeper precisa de assinatura/notarização do responsável. Instale e autentique o Antigravity CLI separadamente se quiser recursos de IA; a busca local não depende desse login. Configure manualmente as pastas permitidas no próprio computador.

## Licença

O código é público para consulta e download. Nenhuma licença de uso, modificação ou redistribuição foi incluída; peça autorização antes de reutilizar ou redistribuir.
