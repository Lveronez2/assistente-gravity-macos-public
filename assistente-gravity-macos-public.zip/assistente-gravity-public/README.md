# Assistente Gravity

**Para instalar em outro Mac:** baixe o ZIP em [Releases](https://github.com/Lveronez2/assistente-gravity/releases/latest) e siga o [guia de instalação e transferência](docs/OUTRO-MAC.md). O branch principal `main` contém o estado atual.

Aplicativo nativo para macOS 26 ou mais recente, em Apple Silicon.

Os controles principais usam o Liquid Glass nativo do SwiftUI (`glassEffect` e estilos de botão do sistema), com cores semânticas para acompanhar os modos claro, escuro e as preferências de acessibilidade do macOS.

A compilação `preview` mantém histórico e preferências próprios. A compilação `release` usa o identificador da instalação original, preserva o histórico legado quando encontrado e guarda novas conversas em Application Support. Crie cada compilação em um diretório de saída separado.

```sh
./build.sh ./build preview
./build.sh ./build-release release
```

## Primeiro uso em outro computador

O Gravity mostra um tutorial automaticamente no primeiro acesso. O passo a passo completo, incluindo links oficiais, está no [guia de primeiro uso](docs/PRIMEIRO-USO.md).

1. Abra o Assistente Gravity e escolha a pasta que será pesquisada. Uma pasta compartilhada de rede pode ser adicionada opcionalmente.
2. Clique em **Instalar e entrar**. O Terminal instala o Antigravity CLI pelo instalador oficial do Google e inicia o fluxo de autenticação.
3. Escolha Google OAuth, entre na sua conta no navegador e conclua o primeiro acesso. Depois, feche o CLI com `Ctrl+D` e volte ao app.
4. Clique em **Começar a usar**. A busca local funciona sem login; a ampliação com Antigravity usa a conta autenticada naquele computador.

O Gravity não pede nem armazena a senha Google. A autenticação fica no chaveiro seguro do sistema operacional e pertence à pessoa conectada naquele computador. O CLI é uma dependência separada, instalada em `~/.local/bin/agy` pelo instalador oficial.

As instruções completas também estão em [docs/PRIMEIRO-USO.md](docs/PRIMEIRO-USO.md). Codex e Claude Code têm uma skill de onboarding no repositório (`.agents/skills/gravity-first-run/` e `.claude/skills/gravity-first-run/`); invoque `$gravity-first-run` no Codex ou `/gravity-first-run` no Claude Code.

## Uso

- Peça a busca em linguagem natural, por exemplo: “logo Poty atualizada”, “KV do Natal da Hugo Fabbri” ou “apresentação da campanha no servidor”. O Gravity procura na pasta principal configurada, nas pastas adicionadas em Ajustes e, opcionalmente, no servidor conectado.
- Use o clipe ou solte uma imagem/documento na busca para orientar uma busca complexa. O app extrai texto/OCR localmente e, ao enviar, fornece a referência à conta Antigravity conectada para comparar contexto visual ou instruções do documento. A referência pode ter até 30 MB.
- A busca usa um índice de nomes e caminhos salvo localmente e atualizado em segundo plano, corrige erros simples de grafia e devolve buscas diretas sem iniciar a IA. O Antigravity entra quando o pedido exige comparação contextual difícil ou quando você anexa uma referência.
- Os resultados exibem uma miniatura maior. Use **Prévia**, **Abrir**, **Finder** ou **Baixar** para Downloads; também é possível arrastar o card para outro aplicativo. Use as setas para selecionar, Enter para abrir, Espaço para pré-visualizar e Esc para cancelar ou recolher o painel.
- A régua inferior mostra tokens reais das chamadas ao Antigravity e a cota do modelo consultada no CLI. Buscas que terminam no índice local não contam como uso do modelo.
- O botão **Perguntar à IA**, no canto inferior direito, abre uma conversa com o Antigravity CLI para responder dúvidas em linguagem natural. A resposta é direta por padrão; a busca de fontes externas só roda quando você pede links/referências ou a pergunta depende de informação atual que precisa ser confirmada.
- As conversas com IA ficam salvas em um grupo próprio no Histórico, separado das buscas de arquivos e logos do Assistente Gravity. A pesquisa de IA não passa as pastas locais autorizadas como raízes ao CLI.
- Os resultados locais permanecem disponíveis durante o refinamento. Se o Antigravity falhar ou ficar sem atividade, o app preserva os arquivos encontrados, tenta recuperar resultados locais e oferece **Tentar novamente**. Somente Esc ou Cancelar indicam interrupção por você. A busca por IA tem limite de 90 segundos sem atividade e cinco minutos no total. O Gravity nunca inventa caminhos para arquivos.

## Configuração

O app lê as preferências `GravityServer`, `GravityLocal`, `GravityWork`, `GravityCLI` e `GravityHistory`. Para ajustar um caminho na versão de teste:

```sh
defaults write com.google.antigravity.assistente.preview GravityServer -string "/Volumes/Dados/DLM/CLIENTES"
```

A versão de uso diário usa o domínio `com.google.antigravity.assistente`. O histórico novo é guardado em `~/Library/Application Support/Assistente Gravity/`; históricos legados são preservados quando encontrados. O diretório local, a pasta compartilhada e o CLI são configurados por computador.

## Distribuição

O pacote atual é destinado a Macs Apple Silicon com macOS 26 ou mais recente. Para distribuição fora da equipe, assine o app com Developer ID e envie para notarização da Apple. A compilação local sem identidade Developer ID não é uma versão pronta para download público sem avisos do macOS.

## Organização e continuidade

Comece por `AGENTS.md`, `docs/ESTADO.md` e `docs/ARQUITETURA.md`. O estado atual fica nesses documentos; não mantenha transcrições ou cópias de sessões no repositório. Builds e dados privados são ignorados pelo Git.
