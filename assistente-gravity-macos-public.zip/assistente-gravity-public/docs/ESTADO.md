# Estado atual

Atualizado em 2026-11-24.

- Produto: 1.6.124, build 132; macOS 26+, Apple Silicon.
- Interface nativa SwiftUI, ícone prismático, painel flutuante, ajustes de aparência e vidro.
- Reflexo prismático das bordas mais luminoso e com ciclo de 20 segundos; a intensidade continua ligada ao controle de vidro e respeita Reduzir Movimento.
- Busca local por índice; refinamento pelo CLI Antigravity.
- O índice de busca é salvo em plist binário, separado por raiz e persistido em segundo plano; a capacidade de 500 mil entradas reserva 200 mil para o servidor, raízes sem resultados são reindexadas e raízes novas disponibilizam lotes parciais durante a leitura.
- O índice de cada raiz atualiza a cada seis horas, reduzindo enumerações repetidas do servidor; buscas de vários termos têm mais tempo para consultar o ramo de cliente na rede e terminar o fallback local.
- Servidor SMB configurado em `/Volumes/Dados/DLM/CLIENTES` e montado neste Mac; a verificação atual encontrou 121 pastas de clientes na raiz e todas estão legíveis.
- Conversas de pesquisa respondidas pelo Antigravity CLI; resultados do DuckDuckGo entram como contexto e fontes clicáveis. Essa modalidade não envia raízes de pastas locais ao CLI.
- Histórico dividido em buscas locais e web, com exclusão individual.
- Organização atual separa Sources, Resources, Assets, docs e tests. A migração de pastas não altera recursos do produto.
- Compilação local ad hoc; distribuição pública exige assinatura/notarização.
- Busca limitada a Documents e às pastas escolhidas em Ajustes. Acesso Total ao Disco foi revogado neste Mac.
- Ajustes mostram as pastas autorizadas em um grupo recolhido por padrão, expansível no mesmo popover com rolagem interna para listas longas.
- Aparência deste Mac alinhada às preferências do ZIP pessoal: AppearanceLightness 1.0 e GlassIntensity 1.0. O histórico não foi restaurado.
- Miniatura recolhida usa a marca prismática circular oficial, com vidro interativo do macOS e sem o ícone quadrado do app.
- Arraste da janela usa o ponto fixo do clique como âncora para o ícone acompanhar o cursor sem deslizamento acumulado.
- Painel expandido tem um feixe prismático nítido na linha da borda e um halo difuso que irradia dele, percorrendo as cores do anel oficial em ciclo de 20 s. A camada fica acima do compositor de vidro; Reduzir Movimento pausa a animação.
- Abertura e minimização animam uma única superfície Liquid Glass contínua entre o círculo da miniatura e o painel, com dimensões SwiftUI alinhadas à área interativa da janela. O conteúdo faz uma entrada curta por opacidade e o glow permanece num overlay externo.
- Pesquisas rápidas são aprendidas localmente por instalação: a linha mostra primeiro a busca mais recente e depois as mais frequentes, sem sincronizar os termos entre computadores.
- `build.sh` aceita `GRAVITY_CODESIGN_IDENTITY` para assinar builds com uma identidade estável. Neste Mac não há identidade de assinatura instalada; builds continuam ad hoc e podem pedir autorização de pastas após recompilação.
- Sliders de aparência e vidro atualizam em tempo real, sem escrita síncrona a cada movimento; persistem ao terminar o gesto. A aparência da janela só troca ao cruzar o ponto neutro.
- Ajustes oferecem intensidade de vidro até 200% e transparência até 100%; tint e contorno ótico crescem com a intensidade, e a aparência escolhida permanece fixada no app, janela e hosting view quando perde foco.
- Primeiro acesso mostra tutorial de instalação e conexão Antigravity/Google com links oficiais. Skills `gravity-first-run` estão disponíveis para Codex e Claude Code no repositório.
- Cards, buscas por caminho e ações de arquivo validam que o caminho resolvido permanece dentro das raízes configuradas.
- Prévia de documentos usa uma janela `QLPreviewView` nativa no app em vez do processo externo `qlmanage`, que estava abortando ao abrir itens no Quick Look.
- A busca aceita uma imagem ou documento de até 30 MB como referência por seleção ou arraste; OCR/texto é extraído localmente, e a busca contextual usa uma cópia temporária limitada ao arquivo escolhido. O tour interativo apresenta essa função.
- A revisão de segurança removeu a indexação automática de pastas comuns e adicionou validação de caminhos absolutos e links simbólicos.
- Próximas validações de produto: busca web real, interação prolongada com arraste e uso em outro Mac.

- 1.6.82: intensidade do vidro ampliada até 150%, controle separado de transparência até 80% e superfícies clara/escura mais luminosas; ambos os controles persistem localmente.
- 1.6.83: vidro e transparência ampliados até 200% e 100%, resposta ótica das bordas vinculada ao controle de intensidade e aparência fixada ao perder/retomar foco.
- 1.6.84: indexação e consulta de cota deixam livre o primeiro quadro; buscas percorrem grupos indexados sem copiar todas as entradas e limitam a ordenação de pastas aos 12 melhores resultados.
- 1.6.85: aparência do tema reforçada no `NSHostingView` e reaplicada após a janela perder foco para evitar o retorno visual ao tema do sistema.
- 1.6.86: Liquid Glass mantém a aparência ativa quando o painel perde foco, evitando que o material fique cinza/inativo independentemente do tema escolhido.
- 1.6.87: adiciona uma camada tonal própria à superfície expandida, modulada pelos controles de intensidade e transparência, para evitar que a composição adaptativa do Liquid Glass clareie ao perder foco.
- 1.6.88: a camada corretiva aparece somente enquanto a janela está fora de foco e acompanha o tom claro/escuro selecionado; some ao voltar para o Gravity para preservar a transparência em uso.
- 1.6.89: reforça o tom selecionado até 85% apenas fora de foco (dependendo da intensidade); em foco, a camada permanece transparente, mesmo com o controle de vidro no máximo.
- 1.6.90: reposiciona a compensação acima da camada nativa Liquid Glass e abaixo dos controles para garantir que ela seja visível quando o painel perde foco.
- 1.6.91: usa o estado `appearsActive` nativo do SwiftUI para mostrar uma camada preta/branca corretiva acima do vidro somente em janelas inativas, sem depender de callbacks do painel não ativador.
- 1.6.92: amplia o índice para 500 mil entradas e reindexa raízes que não geraram resultados; no Mac atual, as pastas locais tinham ocupado o limite anterior e deixado o servidor com zero arquivos indexados.
- 1.6.93: reserva 200 mil posições para o servidor, publica lotes do índice enquanto cada raiz é lida e prioriza servidor e CLIENTES:DESK no fallback curto para que Documentos não consuma o prazo inteiro.
- 1.6.94: quando a consulta cita Desk, a raiz local `CLIENTES:DESK` recebe prioridade antes do SMB no fallback; busca explícita de servidor continua priorizando o compartilhamento.
- 1.6.95: substitui `qlmanage -p` por uma janela de prévia Quick Look nativa e reutilizável; elimina os encerramentos do processo auxiliar observados ao clicar em Prévia.
- 1.6.96: permite anexar ou soltar uma imagem/documento para orientar buscas complexas; o OCR/texto extraído e o arquivo de referência seguem para o Antigravity conectado quando a busca é enviada. Adiciona uma etapa dedicada ao tour.
- 1.6.97: abre o seletor de anexos de forma assíncrona para não bloquear a interface flutuante.
- 1.6.98: corrige o alvo de demonstração do clipe no tour quando o controle nativo não publica sua âncora de layout.
- 1.6.99: fixa o destaque do passo de referência no lado direito da barra, alinhado ao clipe.
- 1.6.100: corrige o deslocamento horizontal do destaque para coincidir com o centro do clipe.
- 1.6.101: alinha o contorno ao clipe usando a âncora da barra de busca, cuja borda termina antes do botão.
- 1.6.102: ancora o passo do tour no próprio ícone do clipe, em vez do botão que o contém.

- Versão 1.6.1: empacotamento para outro Mac, instalador e guia de migração. Sem alteração nas funcionalidades de busca.
- main é a referência para retomada. Pacotes pessoais não pertencem ao GitHub. Ainda falta validação funcional no Mac de destino.

- 1.6.2: novas sessões limpam o rascunho e focam a entrada; cliques comuns não são descartados pelo arraste. Aparência fixada na janela e no SwiftUI com fundo neutro estável. Botão Arquivos e logos permite voltar da pesquisa web.
- Validação 1.6.2: oito verificações automatizadas passaram; UI confirmou troca local/web, limpeza do rascunho, navegação pelo histórico e aparência estável durante troca de app.

- 1.6.3: resultados locais permanecem visíveis durante refinamento; 90 s sem atividade e limite total de 5 min substituem cancelamento fixo. Falhas preservam resultados, tentam recuperação local com prazo de 5 s, salvam histórico e oferecem nova tentativa. Cancelamento explícito tem mensagem própria.
- A segunda tentativa local também tem prazo de 5 s; callbacks atrasados não substituem uma busca mais nova.
- Validação 1.6.3: 16 cenários automatizados com prazos simulados; teste de integração em preview isolada confirmou falha do processo, saída da espera, histórico e nova tentativa com arquivo de fixture. Sem chamadas à conta Google na integração.

- 1.6.20: tour interativo de cinco funções com destaques na interface real, cursor demonstrativo, Próximo/Voltar/Pular e replay em Ajustes. Exibido uma vez antes da configuração no primeiro acesso; sem pesquisas ou login automáticos. Reduzir Movimento remove a animação do cursor.
- Validação 1.6.20: compilação e assinatura locais verificadas; 20 regressões existentes passaram. Tour inspecionado na interface nas cinco etapas e reaberto via Ajustes; nenhuma pesquisa foi enviada pelo tour.
- 1.6.21: índice convertido de JSON para plist binário, com migração em segundo plano e sem gravação integral no início quando as raízes não mudaram. Resultados agrupados por raiz para reduzir o trabalho em cada consulta. A busca agora informa explicitamente quando o servidor não está conectado.
- 1.6.22: filtragem do índice rejeita caminhos por substring antes de tokenizar e mantém somente os dez melhores resultados durante a busca, limitando o custo de consultas com muitos resultados.
- 1.6.23: respostas de IA começam sem a consulta DuckDuckGo de preâmbulo; fontes externas são buscadas quando solicitadas. CLI usa esforço baixo e o fallback local reduz de 3 s para 1,25 s.
- Busca de logos exige evidência do cliente e de contexto de logo no nome/caminho, rejeita nomes de outras marcas, apresentações e variantes de produto não solicitadas (por exemplo, cerveja ao pedir a identidade da Poty), e prioriza a pasta institucional atualizada, vetores e arquivos recentes.
- 1.6.24: busca de logo aceita apenas arquivos de identidade em formatos gráficos, exclui apresentações e produtos não solicitados e prioriza marcas atualizadas.
- 1.6.25: arquivos cuja marca no nome contradiz a pasta do cliente são descartados; quando existe, a busca simples por Poty restringe resultados à identidade atualizada de Poty Cia de Bebidas.
- 1.6.26: a busca por Poty consulta primeiro a pasta de identidade atualizada conhecida no servidor, mesmo antes do índice geral terminar; o caminho prioritário foi ajustado à estrutura real do compartilhamento.
- 1.6.27: a busca prioritária da Poty verifica o servidor antes das unidades locais autorizadas para evitar que um disco externo lento esconda os arquivos institucionais.
- 1.6.28: a pasta prioritária da Poty usa leitura direta dos arquivos do diretório para evitar consultas de metadados demoradas ao SMB.
- 1.6.29: busca validada no app aberto: quatro logos institucionais saem da pasta atualizada no servidor; não aparecem apresentações nem logos de outras marcas.
- 1.6.30: marca prismática acompanha a miniatura até o cabeçalho com geometria compartilhada; abertura tem leve overshoot e minimização fecha em movimento mais curto. O build aceita identidade de assinatura estável por `GRAVITY_CODESIGN_IDENTITY`.
- 1.6.31: experimento de morph por geometria compartilhada substituído pela transição original.
- 1.6.33: curvas de easing e duração do painel foram alinhadas com as transições SwiftUI; a miniatura agora recolhe/retorna em escala assimétrica para criar o pulso de bolha.
- 1.6.34: squash-and-stretch sutil no painel e na miniatura, com spring único para deixar o pulso de bolha mais perceptível sem ficar agressivo.
- 1.6.37: pulso de bolha mais visível, com escala maior, leve inclinação do ícone e overshoot curto numa única curva contínua.
- 1.6.38: modificador de transição conforma a `Animatable` do SwiftUI; escala oval e inclinação agora são interpoladas pela spring, em vez de saltar entre estados.
- 1.6.39: experimento de redimensionamento animado da janela nativa.
- 1.6.40: removido o redimensionamento concorrente que causava travadas; o Liquid Glass agora faz o morph entre miniatura circular e painel com `glassEffectTransition(.matchedGeometry)`, acompanhado por um pulso spring reversível no conteúdo.
- 1.6.41: o vidro da miniatura foi isolado para não agrupar os controles do painel; a máscara compensa o squash para preservar os cantos arredondados e mantém a sombra fora do recorte.
- 1.6.42: morph real entre a casca de vidro circular e a do painel, em container isolado; o conteúdo faz um pulso menor por cima para dar peso ao movimento sem redimensionar a janela.
- 1.6.43: miniatura e painel permanecem juntos no container durante o morph; a forma de origem só sai depois da expansão, seguindo o padrão de morph da Apple e reduzindo o trabalho de layout no spring.

- 1.6.44: janela, índice e telemetria separados em módulos; signposts medem busca e reindexação sem registrar consultas nem caminhos, e a agregação de raízes tem ordem determinística.
- 1.6.45: corrigida a borda dupla e o vazamento visual na abertura: o Liquid Glass troca entre círculo e painel com um único ID de morph e o fundo do painel permanece preenchido durante a animação.
- 1.6.46: glow colorido alinhado diretamente à casca do Liquid Glass; removidos stroke e sombra extras que criavam outro contorno deslocado.
- 1.6.47: casca do Liquid Glass alinhada ao frame da janela; os 10 pt de margem ficam somente no conteúdo, eliminando a moldura externa vazia.
- 1.6.48: glow movido alguns pontos para dentro da casca para evitar o recorte do bloom nos limites da janela; permanece aceso durante o morph. Clique na miniatura agora sempre abre uma conversa nova, sem uma área invisível que desviava alguns cliques ao histórico.
- 1.6.49: camada prismática reposicionada para aparecer acima do conteúdo do painel.
- 1.6.50: restaurada a faixa prismática curta e difusa, sem halo contínuo, mantendo a camada acima do painel para que o Liquid Glass não a esconda.
- 1.6.51: aumentada somente a difusão do highlight móvel para que apareça como luz suave, sem virar um contorno fixo.
- 1.6.54: glow voltou para uma camada independente acima do Liquid Glass e segue ativo durante o morph.
- 1.6.55: recuperadas a difusão e a velocidade do glow da versão anterior ao ajuste que alterou sua aparência.
- 1.6.58: restaurada a composição do painel com Liquid Glass, reflexo e glow em uma única superfície, baseada no commit 19/11 `a1a8796`; o relógio do glow segue independente do morph.
- 1.6.59: feixe central ampliado e reforçado, com halo difuso separado, aplicado acima do GlassEffectContainer para permanecer nítido na borda.

- 1.6.61: springs elásticas e pesquisas rápidas locais por recência e frequência.
- 1.6.62: regressão de fechamento corrigida mantendo a superfície de vidro do painel e a miniatura vivas durante todo o morph; a janela só encolhe depois que a miniatura assume a superfície.
- 1.6.63: glow voltou ao overlay raiz acima do GlassEffectContainer, composição aprovada em `HEAD`; teste estrutural impede que ele volte para dentro do compositor.
- 1.6.64: removida a superfície Liquid Glass duplicada que alterava o contraste do glow; o painel e a miniatura voltam a usar seus próprios materiais pareados.
- 1.6.65: removidas escalas de transição SwiftUI concorrentes com o morph nativo; o spring agora controla diretamente a morphologia Liquid Glass.
- Regressões: 4 cenários de transição, 6 cenários de pesquisas rápidas e 4 verificações do glow/morph, além da suíte existente.

- 1.6.66: layout do host preparado antes da mola de abertura; limpeza do frame após fechamento usa transação sem animação. Glow preservado. Verificações estruturais cobrem o isolamento dessas etapas; fluidez exige validação visual.

- 1.6.67: superfície persistente anima frame e raio dos cantos com uma mola; conteúdo não troca a identidade da superfície. Geometria da miniatura independe do tamanho do host. Base: documentação Apple de animação de propriedades e Liquid Glass.
- 1.6.68: abertura inicia a mola logo após preparar e calcular o layout do host, removendo a espera de um ciclo extra da interface.
- 1.6.69: abertura redimensiona o host sem forçar o layout e a renderização síncrona do painel inteiro antes da mola, removendo o bloqueio do primeiro quadro.
- 1.6.70: abertura encurtada de 540 ms para 320 ms, com balanço elástico moderado; fechamento permanece inalterado.
- 1.6.71: superfície da miniatura e do painel voltou a usar IDs pareados e `.glassEffectTransition(.matchedGeometry)` nativo; conteúdo anima em camada separada e o glow mantém o overlay externo.
- 1.6.72: abertura e fechamento sincronizados em 400 ms com balanço sutil; opacidade do conteúdo harmonizada e animação do glow pausada somente durante o morph.
- 1.6.73: limpeza do frame após fechamento usa redimensionamento sem desenho síncrono; o host reduz naturalmente depois do morph para evitar tranco no último quadro.
- 1.6.74: janela AppKit fica ativa antes do primeiro quadro do morph; foco da busca não é disputado enquanto a janela está recolhida.
- 1.6.75: removido o matched geometry que produzia uma esfera intermediária gigante no fechamento; a mesma superfície interpola dimensões e raio dos cantos.
- 1.6.76: abertura em duas fases: AppKit atualiza os limites do host por um quadro antes da mola SwiftUI, evitando o tranco no primeiro quadro.
- 1.6.77: painel Liquid Glass mantém layout fixo durante abrir/fechar e anima apenas uma transformação de escala no compositor; evita relayout e recálculo da superfície a cada quadro. Feixe prismático continua acima do compositor.
- 1.6.78: escala recolhida usa raio equivalente à metade do painel para a transformação iniciar num círculo, sem cantos retangulares comprimidos.
- 1.6.79: minimização permanece clicável durante o morph, fechar pode interromper uma abertura presa e um watchdog libera interações se a conclusão da animação não retornar.
- 1.6.80: removida a escala fora dos limites da janela que deixava os controles visíveis, mas sem receber cliques. O fechamento pode interromper a abertura; watchdog libera estado de transição.
- 1.6.81: leitura/gravação do histórico e preparação do índice passam para filas de baixa prioridade; paleta do glow é estática e o feixe mantém um único halo para reduzir trabalho de renderização.

- 1.6.103/build 111: arraste exporta somente `public.file-url`, sem sondar conteúdo/metadata SMB na thread da interface. Miniaturas com falha usam ícone genérico sem consulta síncrona ao Finder. Causa do encerramento ainda requer reprodução com o arquivo original; não houve relatório recente disponível.
- 1.6.104/build 112: pesquisas CLI recebem apenas leitura das pastas selecionadas; comandos, alterações de arquivo, MCP e navegação são negados para eliminar confirmações repetidas em buscas.

- 1.6.105/build 113: busca local corrige erros simples de digitação usando vocabulário indexado por raiz; IA fica restrita a consultas contextuais difíceis ou buscas com referência. Removida a negação explícita de comandos sandboxed que causava falha em `run_command`.

- 1.6.106/build 114: correção contextual de marcas privilegia o cliente quando a busca pede logo (incluindo troca de letras em Poty); removido o acesso direto e síncrono à pasta SMB antes da consulta ao índice. Erros corrigidos sem resultado indexado não iniciam varredura lenta de rede.
- 1.6.107/build 115: o índice v2 visita primeiro a pasta de identidade atualizada da Poty no servidor e publica esses resultados antes da varredura geral; termos corrigidos sem resultado indexado não iniciam varredura lenta, e cards do servidor não consultam metadados de tamanho no SMB.
- 1.6.108/build 116: a montagem das raízes de busca não chama `isReadableFile` nem resolve symlinks no compartilhamento SMB durante cada consulta; disponibilidade do servidor fica a cargo do indexador em background.
- 1.6.109/build 117: buscas `logo Poty` e grafias corrigidas consultam primeiro o prefixo curto e priorizado da identidade institucional no índice do servidor, sem atravessar os 200 mil registros SMB.
- 1.6.113/build 121: a busca SMB identifica a pasta do cliente apenas pelo nome, evita ler metadados de cada item na raiz e retorna claramente após varrer uma pasta alvo sem resultados; consultas com vários termos mantêm prazos adaptados à rede.
- 1.6.114/build 122: resultados de logo exigem contexto explícito de logo/identidade, descartam mockups e arquivos gerados, atualizam os arquivos diretamente nas pastas de logo identificadas pelo índice e priorizam logos localizados no servidor.
- 1.6.115/build 123: busca logos no servidor pela pasta exata do cliente, percorre primeiro a área institucional e retorna todas as variantes atuais encontradas no diretório de logos; evita respostas de um único arquivo por índice SMB incompleto.
- 1.6.116/build 124: nomes CamelCase como `MeetingFun.ai` são tokenizados corretamente; buscas de logo conferem a pasta SMB do cliente antes de aceitar o índice parcial e retornam uma mensagem objetiva quando não há logo correspondente, sem cair em uma varredura lenta que pode trazer mockups.
- 1.6.117/build 125: busca de logo consulta a pasta exata do cliente em todas as raízes configuradas, inclusive clientes locais como CLIENTES:DESK, evitando declarar ausência só porque a marca não existe na raiz do servidor.
- 1.6.118/build 126: a busca testa primeiro o caminho direto do cliente em raízes locais e no servidor; se a pasta exata não existe no SMB, pula a enumeração da raiz de rede e informa resultado ausente após a consulta local curta.
- 1.6.119/build 127: o caminho direto do cliente mantém a ordem natural dos termos digitados e considera uma ordem alternativa para nomes de pasta com palavras invertidas.
- 1.6.120/build 128: busca de logo remove termos de intenção ao localizar a pasta do cliente, tokeniza nomes CamelCase no vocabulário, corrige erros de uma edição com candidatos únicos e ordena todos os resultados coletados por data de modificação mais recente.
- 1.6.121/build 129: busca local ignora imediatamente o caminho SMB configurado quando o volume ainda não está montado e continua nas pastas locais autorizadas, sem esperar o prazo da rede.
- 1.6.122/build 130: correção automática exige candidato único com frequência suficiente, não substitui uma consulta que já corresponde a um caminho completo e mantém preferência contextual conhecida para grafias de Poty.
- 1.6.123/build 131: fallback local exclui a raiz SMB mesmo quando ela também consta entre as pastas autorizadas; consultas de logo ganham tempo para concluir no servidor; logo Poty reúne as variantes válidas do Desk e do servidor e mostra a lista por data de modificação, mais recente primeiro. Correção de grafia considera a frequência da forma exata para resolver erros mesmo quando a grafia digitada também existe em arquivos alheios.
- 1.6.124/build 132: índice quente responde antes de qualquer varredura recursiva na rede. A busca SMB por logo só percorre a pasta do cliente quando o índice não tem resultados; isso mantém a busca rápida sem perder o fallback para novos arquivos ainda não indexados.
