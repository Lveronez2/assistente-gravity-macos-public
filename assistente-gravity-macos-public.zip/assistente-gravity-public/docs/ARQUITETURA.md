# Mapa do código

| Local | Responsabilidade |
|---|---|
| Sources/FeatureTour.swift | Tour guiado, âncoras dos controles e cursor demonstrativo |
| Sources/main.swift | Entrada do app, GravityViewModel e composição SwiftUI |
| Sources/WindowCoordinator.swift | Ciclo de vida do painel flutuante, transições e eventos nativos de mouse |
| Sources/SearchIndex.swift | Raízes autorizadas, persistência e ciclo de atualização do índice por pasta |
| Sources/SearchReference.swift | Validação, OCR/text extraction local, staging temporário e escopo de anexos de busca |
| Sources/SmartFinderEngine.swift | Interpretação, ranking e busca de arquivos no índice ou fallback |
| Sources/TokenTelemetry.swift | Modelo da telemetria e cliente/parse das consultas ao Antigravity CLI |
| Sources/RefinementPolicy.swift | Prazos de inatividade/total e preservação de resultados |
| Sources/WindowPointerGesture.swift | Estado do arraste sem descartar cliques comuns |
| Sources/WindowTransitionPolicy.swift | Classificação, temporização e ordem do redimensionamento das transições |
| Sources/QuickSearchHistory.swift | Sugestões de busca locais ranqueadas por recência e frequência |
| Sources/WebResearchEngine.swift | Consulta web sob demanda, parsing e fontes |
| Resources/ | Plist, ícone instalado, anel e comando de autenticação |
| Assets/ | Fontes visuais para edição |
| scripts/ | Instalador e criação de pacote portátil |
| build.sh | Empacotamento e assinatura local |
| tests/ | Regressões da busca, transições da janela e pesquisas rápidas; tests/run.sh |
| .github/workflows/ | Verificações do repositório |
| .agents/skills/, .claude/skills/ | Skills de onboarding para agentes Codex e Claude Code |
| docs/PRIMEIRO-USO.md | Fonte única dos passos e links oficiais de instalação/autenticação |

## Decisões

Mac e Windows permanecem independentes. Recursos são lidos do bundle, não do checkout. O histórico e índice ficam fora do repositório. A versão preview usa domínio e dados separados. `main.swift` permanece o ponto de entrada e coordena o estado e a interface; ciclo de vida da janela, armazenamento de busca e comunicação de telemetria ficam em módulos próprios. O motor de busca mantém as políticas de relevância ao lado da execução da consulta, enquanto o armazenamento e a atualização do índice são isolados.

O índice usa somente `GravityLocal`, pastas explicitamente adicionadas e, quando configurada, `GravityServer`. Resultados externos e caminhos digitados passam pela mesma verificação de raiz resolvida antes de exibir ou operar arquivos. A permissão Acesso Total ao Disco não é requisito do app. O Antigravity CLI ainda roda fora de App Sandbox, então os diretórios passados por `--add-dir` não são isolamento imposto pelo sistema operacional.

O índice local é persistido como plist binário, agrupado por raiz. Migração do JSON antigo e gravações usam uma fila de baixa prioridade; abrir o app não serializa novamente o índice se as raízes autorizadas não mudaram. A capacidade global de 500 mil entradas reserva 200 mil para o servidor; lotes de raízes novas já ficam pesquisáveis durante a enumeração, e raízes sem resultados são atualizadas novamente. Cada raiz com resultados é reindexada após seis horas, evitando varreduras integrais repetidas do compartilhamento SMB. `GravityServer` é um caminho local já montado pelo macOS, e a aplicação não tenta adivinhar host ou credenciais SMB.

Correção ortográfica consulta vocabulário por raiz, tokenizado a partir do nome original e caminho original para preservar CamelCase. Termos com uma edição de distância são corrigidos apenas quando há um candidato único mais forte; logo, a busca usa o nome do cliente sem palavras de intenção para abrir a pasta exata. Resultados são ordenados por data de modificação decrescente, com relevância como desempate, e exibem até 100 arquivos por consulta.

O Instruments recebe signposts de duração para busca local e reindexação por raiz. Os eventos registram apenas tamanho da consulta e se a busca é local; não registram texto da consulta nem caminhos. Resultados concatenam raízes em ordem determinística antes do ranking.

Consultas web em conversas rápidas chamam o Antigravity CLI imediatamente com esforço baixo. A busca DuckDuckGo separada só é iniciada quando a pessoa pede fontes ou links; a busca local por índice continua primeiro e seu fallback recursivo fica limitado a 1,25 s antes do refinamento com IA. Para esse fallback, o SMB vem primeiro na busca geral, CLIENTES:DESK vem primeiro na busca local e Documents fica depois das raízes específicas.

Um feixe prismático nítido percorre a linha da borda em ciclo de 20 segundos; seu halo difuso irradia do próprio feixe. A camada fica acima do compositor de vidro e independente do morph da janela; somente Reduzir Movimento pausa o ciclo.

A carga e a persistência do histórico usam uma fila serial de baixa prioridade. A preparação do índice de pastas também começa fora da thread principal, pois pode ler snapshots grandes ou consultar volumes montados. O glow mantém a paleta fora dos ciclos da TimelineView e usa um único halo desfocado.

A prévia rápida de arquivos usa `QLPreviewView` em uma janela AppKit reutilizável, dentro do próprio Gravity. Não lance `/usr/bin/qlmanage -p`: no sistema atual esse processo auxiliar aborta ao abrir algumas prévias de mídia.

Anexos de busca aceitam uma imagem ou documento escolhido explicitamente (até 30 MB). O app copia somente esse arquivo para uma pasta temporária privada, extrai texto/OCR localmente e fornece o arquivo ao Antigravity apenas quando o usuário envia a busca; a pasta temporária é removida ao descartar a referência ou após uma resposta concluída. O clique no clipe e o texto junto ao anexo informam que o conteúdo será analisado pela conta Antigravity conectada. As instruções do documento servem como critérios de busca e não autorizam comandos, alterações de arquivos ou acesso fora das raízes já configuradas.

Busca de identidade visual deve confirmar tanto a marca quanto o contexto de logo no nome ou no caminho. O filtro local aceita formatos gráficos, exclui apresentações e variantes de produto que não foram pedidas e prioriza marcas atualizadas e arquivos recentes. O refinamento por IA segue os mesmos limites.

Para Poty, a pasta prioritária é consultada diretamente em `POTY/_LOGOS POTY/MARCAS ATUALIZADAS/Poty Cia de Bebidas`, antes da resposta do índice geral e antes das unidades locais autorizadas. A leitura é limitada à listagem imediata do diretório, evitando consultas de metadados recursivas ao SMB.

A tela de primeiro acesso é controlada por `GravitySetupComplete`; o instalador do pacote redefine essa preferência para que o tutorial apareça no Mac de destino. As skills do Codex e do Claude Code apontam para `docs/PRIMEIRO-USO.md`, que mantém os passos e links atualizados em um só lugar.

A autorização de arquivos protegidos pelo macOS depende da identidade de assinatura do app. `build.sh` usa assinatura ad hoc para desenvolvimento quando `GRAVITY_CODESIGN_IDENTITY` não está definida; mudanças no executável podem ser tratadas pelo macOS como um app diferente. Para preservar a identidade entre builds, configure uma identidade de assinatura estável instalada no Mac. O suporte existe no build, mas este computador não tem um certificado de assinatura disponível.

A abertura e minimização mantêm a casca do Liquid Glass no `ZStack` e o enquadramento superior-direito. A janela troca de tamanho sem uma segunda animação AppKit concorrente com o morph SwiftUI. Um clique na miniatura sempre abre uma conversa nova; o histórico continua acessível no painel e pelo menu contextual.

A miniatura e o painel compartilham uma única superfície Liquid Glass cujo frame acompanha a área interativa da janela. Evitamos desenhar a interface fora dos limites do host para que o painel visível receba cliques. O conteúdo entra em uma camada separada com transição curta de opacidade; o glow fica acima do GlassEffectContainer e pausa enquanto o morph acontece. O host AppKit cresce antes da abertura e encolhe após o fechamento, sem desenho síncrono. O botão de minimizar continua disponível durante a transição, que também tem um watchdog de recuperação.

- 1.6.103/build 111: arraste exporta somente `public.file-url`, sem sondar conteúdo/metadata SMB na thread da interface. Miniaturas com falha usam ícone genérico sem consulta síncrona ao Finder. Causa do encerramento ainda requer reprodução com o arquivo original; não houve relatório recente disponível.
- 1.6.113/build 121: além dos prazos adaptativos, a busca em SMB lista nomes da raiz sem carregar metadados de todos os itens, escolhe a pasta do cliente e encerra com uma resposta precisa quando essa pasta foi varrida e não há correspondência. Isso elimina varreduras inúteis por outros diretórios após o cliente alvo já ter sido verificado.
- 1.6.114/build 122: consultas por logo validam contexto explícito de logo/identidade e descartam mockups/gerações. Para evitar resultados incompletos de um índice SMB desatualizado, a busca relê somente arquivos nas pastas de logo do cliente já identificadas no índice e prioriza resultados do servidor.
- 1.6.115/build 123: a busca por logo encontra o diretório do cliente na raiz SMB e percorre uma árvore pequena, priorizando a área institucional. O resultado vem da pasta atual de logos, mesmo se o índice geral ainda não a contiver.
- 1.6.116/build 124: tokenização separa palavras CamelCase em nomes de arquivo; buscas de logo priorizam a varredura curta da pasta exata do cliente sobre resultados parciais do índice e encerram com resposta explícita quando não há correspondência.
- 1.6.117/build 125: a busca direcionada verifica pastas de cliente locais e SMB, com prioridade para o servidor e para CLIENTES:DESK, antes de aceitar um índice incompleto.
- 1.6.118/build 126: consulta caminhos diretos de cliente em vez de enumerar a raiz SMB quando não há diretório exato correspondente, preservando a busca rápida em pastas locais.
- 1.6.119/build 127: a busca monta o caminho do cliente na ordem do pedido e tenta uma variação de ordem para pastas que não correspondem à sequência digitada.
