# Primeiro uso do Assistente Gravity

Este guia cobre o app para macOS e o Antigravity CLI. O Gravity requer macOS 26 ou mais recente e Apple Silicon.

## Instalar o app

- Para usar o app pronto, baixe o ZIP mais recente em [Releases do Assistente Gravity](https://github.com/Lveronez2/assistente-gravity/releases/latest), descompacte-o e execute `Instalar.command`. Não baixe “Source code” esperando encontrar o aplicativo instalado.
- Para compilar o repositório, instale as ferramentas de linha de comando do Xcode com um SDK macOS 26+ e execute `./build.sh ./build release`. A compilação local usa assinatura ad hoc; veja os requisitos de distribuição no [README](../README.md).
- Se o Gatekeeper bloquear um pacote localmente assinado, siga a seção “Se o macOS bloquear a abertura” em [Instalar e continuar em outro Mac](OUTRO-MAC.md). Não desative o Gatekeeper.

## Configurar a primeira vez

Na primeira abertura, o Gravity apresenta um tour interativo de cinco funções: busca, perguntas à IA, histórico, ajustes e minimizar. Um cursor demonstrativo aponta os controles; os botões Próximo, Voltar e Pular controlam o ritmo. Nenhuma consulta ou autenticação é executada pelo tour. Depois, o Gravity exibe a configuração abaixo. O tour pode ser reaberto em **Ajustes → Rever tour do Gravity**.

Configuração:

1. Escolha a pasta local que o Gravity pode pesquisar. O acesso fica limitado a essa pasta e às demais pastas adicionadas depois em Ajustes.
2. Clique em **Instalar e entrar**. O Terminal abre o instalador oficial do Antigravity CLI se `agy` ainda não estiver instalado; confirme no próprio Terminal para continuar. Se o CLI já estiver instalado, o botão abre diretamente o Antigravity.
3. No CLI, escolha Google OAuth para uma conta pessoal e conclua a autenticação no navegador. O Antigravity CLI guarda a sessão no chaveiro seguro do sistema; o Gravity não pede nem armazena sua senha ou código OAuth.
4. Depois do login, feche o CLI com `Ctrl+D` e volte ao Gravity. **Verificar instalação** confirma que o binário `agy` existe em `~/.local/bin/agy`; não verifica se a sessão Google está autenticada.
5. Clique em **Começar a usar**. A busca local funciona sem login; recursos que chamam o Antigravity precisam de uma sessão conectada.

Na primeira execução, o CLI também pode perguntar preferências de cor, modo de renderização e se você confia no diretório de workspace. O script do Gravity abre um workspace próprio em `~/Library/Application Support/Assistente Gravity/Antigravity Workspace`.

O botão de instalação executa [este script incluído no pacote](../Resources/connect-antigravity.command). Se preferir conferir as instruções oficiais, veja [instalação e início rápido do CLI](https://antigravity.google/docs/getting-started?tab=cli) e [autenticação Google do Antigravity](https://antigravity.google/docs/install?tab=cli).

## Problemas comuns

- **O Gravity diz que o CLI não está instalado:** clique em **Verificar instalação**. O app procura o executável no caminho padrão `~/.local/bin/agy`. Se você instalou o CLI em outro local, configure o caminho conforme a seção “Configuração” do [README](../README.md).
- **O navegador não concluiu o login:** retorne ao Terminal e termine o fluxo do Antigravity antes de fechar a janela. A autenticação é feita pelo Google diretamente no navegador.
- **Precisa configurar outro computador:** veja [Instalar e continuar em outro Mac](OUTRO-MAC.md). Preferências, histórico e credenciais são próprios de cada computador.
