# Gravity repository guidance

Read `AGENTS.md`, `docs/ESTADO.md`, and `docs/ARQUITETURA.md` before changing the app.

For installation, first launch, Antigravity CLI, or Google sign-in questions, use the `gravity-first-run` skill in `.claude/skills/gravity-first-run/SKILL.md` and its linked `docs/PRIMEIRO-USO.md` guide. The app’s welcome screen appears when `GravitySetupComplete` is false.
