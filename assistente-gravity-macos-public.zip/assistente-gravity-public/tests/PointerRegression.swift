import Foundation
import CoreGraphics
var gesture = WindowPointerGesture()
// Pointer movement on ordinary controls must not consume mouse-up.
gesture.begin(at: .zero, canDrag: false)
assert(!gesture.update(to: CGPoint(x: 20, y: 20)))
assert(!gesture.end())
// A click without drag events must reach the view.
gesture.begin(at: .zero, canDrag: true)
assert(!gesture.end())
// Minor hand movement on the header remains a click.
gesture.begin(at: .zero, canDrag: true)
assert(!gesture.update(to: CGPoint(x: 2, y: 2)))
assert(!gesture.end())
// A real drag remains a drag even if it returns to its start.
gesture.begin(at: .zero, canDrag: true)
assert(gesture.update(to: CGPoint(x: 12, y: 0)))
assert(gesture.update(to: .zero))
assert(gesture.end())
assert(!gesture.end())
print("4 regressões de ponteiro passaram")
