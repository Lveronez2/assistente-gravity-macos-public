import Foundation

guard CommandLine.arguments.count == 4,
      let app = try? String(contentsOfFile: CommandLine.arguments[1], encoding: .utf8),
      let search = try? String(contentsOfFile: CommandLine.arguments[2], encoding: .utf8),
      let index = try? String(contentsOfFile: CommandLine.arguments[3], encoding: .utf8) else {
    fatalError("Informe main.swift, SmartFinderEngine.swift e SearchIndex.swift")
}

guard let initStart = app.range(of: "    init() {", range: app.range(of: "final class GravityViewModel")!.lowerBound..<app.endIndex),
      let initEnd = app.range(of: "    func chooseSearchFolder()", range: initStart.upperBound..<app.endIndex) else {
    fatalError("Não foi possível localizar a inicialização do ViewModel")
}
let initializer = String(app[initStart.lowerBound..<initEnd.lowerBound])
assert(initializer.contains("loadSavedConversations()"))
assert(initializer.contains("DispatchQueue.main.asyncAfter(deadline: .now() + 1.25)"))
assert(initializer.contains("DispatchQueue.main.asyncAfter(deadline: .now() + 2.0)"))
assert(initializer.contains("SmartFinderEngine.scheduleIndexing()"))
assert(initializer.contains("refreshTokenTelemetry()"))
assert(!initializer.contains("SmartFinderEngine.startIndexing()"), "O primeiro acesso ao índice não pode ocorrer na thread principal")
assert(!initializer.contains("SmartFinderEngine.scheduleIndexing()\n        refreshTokenTelemetry()"), "Setup e consulta de cota não podem iniciar junto ao primeiro frame")

guard let loadStart = app.range(of: "    func loadSavedConversations()"),
      let loadEnd = app.range(of: "    private func finishLoadingConversations", range: loadStart.upperBound..<app.endIndex),
      let saveStart = app.range(of: "    func persistConversations()"),
      let saveEnd = app.range(of: "    private func recordTurnInHistory", range: saveStart.upperBound..<app.endIndex) else {
    fatalError("Não foi possível localizar o acesso ao histórico")
}
let load = String(app[loadStart.lowerBound..<loadEnd.lowerBound])
let save = String(app[saveStart.lowerBound..<saveEnd.lowerBound])
assert(load.contains("historyIOQueue.async") && load.contains("Data(contentsOf:"), "Leitura e parse do histórico devem rodar fora da thread principal")
assert(save.contains("historyIOQueue.async") && save.contains("JSONEncoder().encode") && save.contains("data.write(to:"), "Persistência do histórico deve rodar em fila serial de baixa prioridade")
assert(app.contains("pendingHistoryPersist"), "Uma gravação não pode antecipar a carga inicial e apagar histórico")

guard let glowStart = app.range(of: "private struct AnimatedEdgeLight: View"),
      let glowEnd = app.range(of: "// MARK: - Modelos de Dados", range: glowStart.upperBound..<app.endIndex) else {
    fatalError("Não foi possível localizar o glow animado")
}
let glow = String(app[glowStart.lowerBound..<glowEnd.lowerBound])
assert(glow.range(of: "private static let logoPalette")!.lowerBound < glow.range(of: "var body: some View")!.lowerBound,
       "A paleta fixa do glow deve ser criada fora do ciclo da TimelineView")
assert(glow.components(separatedBy: ".blur(radius:").count - 1 == 1,
       "O feixe mantém apenas um halo desfocado para reduzir o trabalho de composição")

assert(search.contains("private static let indexSetupQueue"))
assert(search.contains("static func scheduleIndexing()"))
assert(search.contains("indexSetupQueue.async { startIndexing() }"), "Leitura e reconciliação do índice devem sair da thread principal")
assert(index.contains("func entryGroups(matching roots: Set<String>) -> [[SearchIndexEntry]]"))
assert(index.contains("return roots.sorted().compactMap { entriesByRoot[$0] }"), "Buscas devem compartilhar arrays indexados em vez de copiar a lista inteira")
assert(search.contains("entryGroups.lazy.joined()"), "A busca deve percorrer os grupos sem materializar outra lista de arquivos")
assert(search.contains("if matches.count > 12 { matches.removeLast() }"), "Busca por pastas deve limitar ordenação aos 12 melhores resultados")

print("Responsividade: inicialização adiada, buscas sem cópia do índice e glow com composição reduzida")
