import Foundation

guard CommandLine.arguments.count == 2,
      let source = try? String(contentsOfFile: CommandLine.arguments[1], encoding: .utf8),
      let rootStart = source.range(of: "struct GravityRootView: View")?.lowerBound,
      let nextSection = source[ rootStart... ].range(of: "// MARK: 1. Miniatura Flutuante")?.lowerBound else {
    fatalError("Não foi possível localizar a composição raiz do Gravity")
}

let root = String(source[rootStart..<nextSection])
guard let glassContainer = root.range(of: "GlassEffectContainer(spacing: 24)"),
      let edgeGlow = root.range(of: "AnimatedEdgeLight("),
      let rootOverlay = root.range(of: ".overlay {", range: glassContainer.upperBound..<edgeGlow.lowerBound) else {
    fatalError("O glow precisa estar em um overlay externo ao contêiner de vidro")
}

assert(rootOverlay.lowerBound > glassContainer.lowerBound)
assert(edgeGlow.lowerBound > rootOverlay.lowerBound)
assert(!root[..<rootOverlay.lowerBound].contains("AnimatedEdgeLight("),
       "O glow não pode ser anexado dentro do conteúdo expandido")

assert(root.contains("WindowTransitionPolicy.surfaceSize"), "A superfície deve acompanhar a área de hit testing da janela")
assert(!root.contains(".scaleEffect(x: expanded ? 1 : collapsedScale.width"), "A superfície não pode ser desenhada fora dos limites interativos")
assert(root.contains("WindowTransitionPolicy.surfaceCornerRadius"), "A superfície compartilhada deve interpolar seus cantos")
assert(root.components(separatedBy: ".glassEffect(.regular.tint(glassTint), in: .rect(cornerRadius: radius))").count - 1 == 1,
       "Miniatura e painel precisam manter uma única superfície Liquid Glass")
assert(!root.contains(".glassEffectID(\"gravity-shell\""), "A transição não pode usar o morph que cria um círculo gigante")
assert(!root.contains(".glassEffectTransition(.matchedGeometry)"), "A superfície não deve saltar entre geometrias independentes")
assert(root.contains("isActive: expanded && !vm.isWindowTransitioning"),
       "O glow deve pausar apenas enquanto o morph está em andamento")
assert(root.contains("if vm.uiMode != .bubble { searchFocused = true }"),
       "A busca não pode receber foco enquanto o painel está recolhido")
assert(root.contains(".allowsHitTesting(!vm.showFeatureTour)"), "A interface não pode desativar toda a área interativa durante o morph")
print("Superfície única sem círculo fantasma e glow externo: regressões passaram")

let coordinatorURL = URL(fileURLWithPath: CommandLine.arguments[1]).deletingLastPathComponent().appendingPathComponent("WindowCoordinator.swift")
let coordinator = try String(contentsOf: coordinatorURL, encoding: .utf8)
assert(!coordinator.contains("await Task.yield()"), "A abertura não pode bloquear aguardando outro executor")
assert(!coordinator.contains("setHostFrame") && !coordinator.contains("displayIfNeeded()"),
       "Nenhuma ponta do morph pode forçar desenho síncrono do host")
assert(!coordinator.contains("layoutSubtreeIfNeeded()"), "O redimensionamento não pode bloquear o loop de interface")
assert(coordinator.contains("scheduleTransitionWatchdog("), "Transições precisam de um desbloqueio de segurança")
assert(coordinator.contains("toBubble: mode == .bubble"), "O fechamento deve poder interromper uma abertura presa")
guard let openingStart = coordinator.range(of: "else if transitionStyle == .opening {"),
      let closingStart = coordinator.range(of: "} else if transitionStyle == .closing {", range: openingStart.upperBound..<coordinator.endIndex) else {
    fatalError("Não foi possível localizar o trecho da abertura")
}
let opening = String(coordinator[openingStart.lowerBound..<closingStart.lowerBound])
guard let preparedHost = opening.range(of: "window.setFrame(newFrame, display: false, animate: false)"),
      let openingSpring = opening.range(of: "withAnimation(") else {
    fatalError("A abertura precisa redimensionar o host e iniciar a mola")
}
assert(preparedHost.lowerBound < openingSpring.lowerBound, "O host deve ser redimensionado antes da mola")
guard let settle = opening.range(of: "DispatchQueue.main.asyncAfter"),
      let settleDelay = opening.range(of: "WindowTransitionPolicy.openingLayoutSettleDelay") else {
    fatalError("A abertura precisa aguardar a atualização dos limites do host")
}
assert(preparedHost.lowerBound < settle.lowerBound && settle.lowerBound < openingSpring.lowerBound,
       "O host deve ganhar um quadro para atualizar antes da animação")
assert(settleDelay.lowerBound < openingSpring.lowerBound,
       "A pausa deve ser limitada ao tempo de um quadro")
assert(!opening.contains("layoutSubtreeIfNeeded") && !opening.contains("displayIfNeeded"),
       "A abertura não pode renderizar o painel inteiro de forma síncrona")
guard let transitionStart = coordinator.range(of: "func transitionWindow(to mode:"),
      let activation = coordinator.range(of: "window.makeKeyAndOrderFront(nil)", range: transitionStart.lowerBound..<openingStart.lowerBound) else {
    fatalError("A janela deve ser ativada antes do morph")
}
assert(activation.lowerBound < openingStart.lowerBound,
       "A janela precisa estar ativa antes de iniciar a abertura")
guard let closeResize = coordinator.range(of: "self.window.setFrame(newFrame, display: false, animate: false)", range: closingStart.upperBound..<coordinator.endIndex) else {
    fatalError("O painel deve encolher após concluir o morph de fechamento")
}
assert(closeResize.lowerBound > closingStart.lowerBound, "O host só pode encolher depois da mola")
print("Abertura e fechamento sem desenho síncrono: 6 verificações passaram")
