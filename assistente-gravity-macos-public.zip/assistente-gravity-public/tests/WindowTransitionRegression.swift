import Foundation

assert(WindowTransitionPolicy.canBegin(isTransitioning: false))
assert(!WindowTransitionPolicy.canBegin(isTransitioning: true))
assert(WindowTransitionPolicy.canBegin(isTransitioning: true, toBubble: true))

let opening = WindowTransitionPolicy.style(fromBubble: true, toBubble: false, reduceMotion: false)
assert(opening == .opening)
assert(WindowTransitionPolicy.resizesFrameBeforeAnimation(for: opening))
assert(!WindowTransitionPolicy.resizesFrameAfterAnimation(for: opening))
assert(WindowTransitionPolicy.openingDuration == 0.40)
assert(WindowTransitionPolicy.openingBounce == 0.12)
assert(abs(WindowTransitionPolicy.openingLayoutSettleDelay - 1.0 / 60.0) < 0.0001)
assert(WindowTransitionPolicy.watchdogDelay(for: .opening) > WindowTransitionPolicy.openingDuration)
assert(WindowTransitionPolicy.panelContentFadeDuration == 0.24)
assert(WindowTransitionPolicy.orbFadeDuration == 0.14)

let closing = WindowTransitionPolicy.style(fromBubble: false, toBubble: true, reduceMotion: false)
assert(closing == .closing)
assert(!WindowTransitionPolicy.resizesFrameBeforeAnimation(for: closing))
assert(WindowTransitionPolicy.resizesFrameAfterAnimation(for: closing))
assert(WindowTransitionPolicy.closingDuration == 0.40)
assert(WindowTransitionPolicy.closingBounce == 0.16)
assert(WindowTransitionPolicy.watchdogDelay(for: .closing) > WindowTransitionPolicy.closingDuration)

let expandedNavigation = WindowTransitionPolicy.style(fromBubble: false, toBubble: false, reduceMotion: false)
assert(expandedNavigation == .resizing)
assert(!WindowTransitionPolicy.resizesFrameBeforeAnimation(for: expandedNavigation))
assert(!WindowTransitionPolicy.resizesFrameAfterAnimation(for: expandedNavigation))

let reducedMotion = WindowTransitionPolicy.style(fromBubble: true, toBubble: false, reduceMotion: true)
assert(reducedMotion == .immediate)
assert(WindowTransitionPolicy.resizesFrameBeforeAnimation(for: reducedMotion))
assert(!WindowTransitionPolicy.resizesFrameAfterAnimation(for: reducedMotion))

print("Transições bubble/painel: 4 regressões passaram")

let available = CGSize(width: 560, height: 480)
assert(WindowTransitionPolicy.surfaceSize(expanded: false, available: available) == CGSize(width: 64, height: 64))
assert(WindowTransitionPolicy.surfaceSize(expanded: true, available: available) == available)
assert(WindowTransitionPolicy.surfaceCornerRadius(expanded: false) == 32)
assert(WindowTransitionPolicy.surfaceCornerRadius(expanded: true) == 20)
print("Morfologia e geometria da janela: 4 regressões passaram")
