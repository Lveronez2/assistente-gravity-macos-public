import Foundation

var history = QuickSearchHistory()
assert(history.suggestions().isEmpty)

history.record("logo da marca", at: Date(timeIntervalSince1970: 10))
history.record("clientes", at: Date(timeIntervalSince1970: 20))
history.record("Logo da MARCA", at: Date(timeIntervalSince1970: 30))
history.record("  briefing   natal ", at: Date(timeIntervalSince1970: 40))

let suggestions = history.suggestions()
assert(suggestions.first == "briefing natal", "A pesquisa mais recente deve aparecer primeiro")
assert(suggestions[1] == "Logo da MARCA", "Pesquisas mais frequentes devem vir em seguida")
assert(suggestions.count == 3, "Pesquisas repetidas ignorando caixa e espaços devem ser agrupadas")
assert(history.suggestions(limit: 2).count == 2)
assert(history.suggestions(limit: 0).isEmpty)

let data = try JSONEncoder().encode(history)
let restored = try JSONDecoder().decode(QuickSearchHistory.self, from: data)
assert(restored.suggestions() == suggestions, "O histórico local deve sobreviver à reinicialização")

print("Pesquisas rápidas locais: 6 regressões passaram")
