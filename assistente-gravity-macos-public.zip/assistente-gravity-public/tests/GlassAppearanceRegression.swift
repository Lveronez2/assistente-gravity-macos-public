import Foundation

func close(_ lhs: Double, _ rhs: Double, tolerance: Double = 0.0001) -> Bool {
    abs(lhs - rhs) <= tolerance
}

assert(GlassAppearancePolicy.maximumIntensity == 2.0)
assert(GlassAppearancePolicy.maximumTransparency == 1.0)
assert(GlassAppearancePolicy.clampedIntensity(-0.1) == 0)
assert(GlassAppearancePolicy.clampedIntensity(2.8) == 2.0)
assert(GlassAppearancePolicy.clampedTransparency(-0.1) == 0)
assert(GlassAppearancePolicy.clampedTransparency(1.2) == 1.0)

assert(GlassAppearancePolicy.surfaceBrightness(isLight: true) == 1.0)
assert(GlassAppearancePolicy.surfaceBrightness(isLight: false) == 0.34)
assert(close(GlassAppearancePolicy.surfaceOpacity(intensity: 0.65, transparency: 0), 0.8155))
assert(close(GlassAppearancePolicy.surfaceOpacity(intensity: 0.65, transparency: 1.0), 0.1355))
assert(close(GlassAppearancePolicy.surfaceOpacity(intensity: 2.0, transparency: 1.0), 0.08))
assert(close(GlassAppearancePolicy.surfaceOpacity(intensity: 0, transparency: 0), 0.90))
assert(close(GlassAppearancePolicy.edgeOpticalStrength(intensity: 0), 0.45))
assert(close(GlassAppearancePolicy.edgeOpticalStrength(intensity: 1), 0.725))
assert(GlassAppearancePolicy.edgeOpticalStrength(intensity: 2) == 1)
assert(close(GlassAppearancePolicy.focusStabilizerOpacity(intensity: 2, transparency: 1, appearsActive: false), 0.70))
assert(close(GlassAppearancePolicy.focusStabilizerOpacity(intensity: 0, transparency: 1, appearsActive: false), 0.55))
assert(GlassAppearancePolicy.focusStabilizerOpacity(intensity: 2, transparency: 1, appearsActive: true) == 0)
assert(GlassAppearancePolicy.focusStabilizerOpacity(intensity: 2, transparency: 0, appearsActive: false) == 0)

let sourcePath = CommandLine.arguments[1]
let source = try String(contentsOfFile: sourcePath, encoding: .utf8)
assert(source.contains("Label(\"Intensidade do vidro\""))
assert(source.contains("Label(\"Transparência do vidro\""))
assert(source.contains("GravityGlassIntensity"))
assert(source.contains("GravityGlassTransparency"))
assert(source.contains("GlassAppearancePolicy.clampedIntensity("))
assert(source.contains("vm.persistGlassIntensity()"))
assert(source.contains("vm.persistGlassTransparency()"))
assert(source.contains("GlassAppearancePolicy.edgeOpticalStrength(intensity: vm.glassIntensity)"))
assert(source.contains("private var windowAppearsActive"))
assert(source.contains(".background(panelStableWash, in: RoundedRectangle(cornerRadius: 20, style: .continuous))"))
assert(source.contains("GlassAppearancePolicy.focusStabilizerOpacity("))
assert(source.contains("appearsActive: windowAppearsActive"))
assert(source.contains("in: 0...GlassAppearancePolicy.maximumIntensity"))
assert(source.contains("in: 0...GlassAppearancePolicy.maximumTransparency"))

let coordinatorPath = URL(fileURLWithPath: sourcePath).deletingLastPathComponent().appendingPathComponent("WindowCoordinator.swift")
let coordinator = try String(contentsOf: coordinatorPath, encoding: .utf8)
assert(coordinator.contains("func applicationDidResignActive("))
assert(coordinator.contains("func windowDidResignKey("))
assert(coordinator.contains("NSApp.appearance = appearance"))
assert(coordinator.contains("window?.contentView?.appearance = appearance"))
assert(coordinator.contains("private final class GravityHostingView: NSHostingView<GravityRootView>"))
assert(coordinator.contains("override func viewDidChangeEffectiveAppearance()"))
assert(coordinator.contains("reassertAppearanceAfterFocusChange()"))
assert(coordinator.contains("hostingView?.lockAppearance(appearance)"))

print("Regressões da aparência do vidro passaram")
