import Foundation

var watchdog = RefinementWatchdog(now: 0)
assert(watchdog.timeoutReason(at: 89) == nil)
assert(watchdog.timeoutReason(at: 90)?.contains("sem responder") == true)

// An active search must survive the previous fixed 90-second deadline.
for second in stride(from: 30, through: 270, by: 30) {
    watchdog.noteActivity(at: Double(second))
    assert(watchdog.timeoutReason(at: Double(second)) == nil)
}
assert(watchdog.timeoutReason(at: 300)?.contains("cinco minutos") == true)

var stalled = RefinementWatchdog(now: 0)
stalled.noteActivity(at: 80)
assert(stalled.timeoutReason(at: 160) == nil)
assert(stalled.timeoutReason(at: 170)?.contains("sem responder") == true)

let local = "**1 arquivo encontrado**\n:::gravity-file:Zml4dHVyZQ==:::"
let partial = "Estou comparando os arquivos"
for reason in ["Serviço indisponível.", "Sem resposta.", "Limite de duração."] {
    // Preserve complete local cards byte-for-byte in every failure scenario.
    assert(RefinementRecovery.message(local: local, partial: partial, reason: reason) == local)
    let response = RefinementRecovery.message(local: nil, partial: partial, reason: reason)
    assert(response.contains(partial) && response.contains(reason))
    assert(!response.contains("Operação cancelada"))
}
let empty = RefinementRecovery.message(local: "  ", partial: "", reason: "Sem resposta.")
assert(empty.contains("Sem resposta.") && empty.contains("Tentar novamente"))
let streaming = RefinementRecovery.streaming(local: local, partial: partial)
assert(streaming.contains(local) && streaming.contains(partial))
assert(RefinementRecovery.streaming(local: local, partial: "") == local)
assert(RefinementRecovery.streaming(local: nil, partial: partial) == partial)
assert(!RefinementRecovery.hasFiles("Busca local parcial. Refine com o cliente."))
let noFiles = RefinementRecovery.message(local: "Busca local parcial.", partial: nil, reason: "Sem resposta.")
assert(noFiles.contains("Sem resposta.") && noFiles.contains("Tentar novamente"))
assert(RefinementRecovery.streaming(local: "Busca local parcial.", partial: partial) == partial)
print("8 cenários de prazo e recuperação passaram (tempo simulado)")
